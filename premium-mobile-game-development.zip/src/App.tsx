import { useState } from 'react';
import {
  Crosshair,
  Shield,
  Zap,
  Map as MapIcon,
  Users,
  Volume2,
  VolumeX,
  Smartphone,
  ChevronRight,
  ChevronLeft,
  Award,
  Sparkles,
  Lock,
  Check,
  Play,
  GitBranch,
  Flame,
  Wifi,
  Compass,
} from 'lucide-react';
import {
  GAME_MODES,
  GameModeSpec,
  Language,
  OPERATORS,
  Operator,
  UI_TEXT,
  WEAPONS,
  WeaponSpec,
} from './data/gameData';
import { soundEngine } from './utils/soundEngine';
import { WeaponArtwork } from './components/WeaponArtwork';
import { BattleArena } from './components/BattleArena';
import { ApkGithubModal } from './components/ApkGithubModal';
import lobbyBgImg from './assets/images/lobby-bg.jpg';
import appIconImg from './assets/images/app-icon.png';
import mapEclipseImg from './assets/images/map-eclipse.jpg';

type NavTab = 'lobby' | 'heroes' | 'armory' | 'map';

export function App() {
  const [lang, setLang] = useState<Language>('bn');
  const [activeTab, setActiveTab] = useState<NavTab>('lobby');
  const [selectedOperator, setSelectedOperator] = useState<Operator>(OPERATORS[0]);
  const [selectedWeapon, setSelectedWeapon] = useState<WeaponSpec>(WEAPONS[0]);
  const [unlockedWeapons, setUnlockedWeapons] = useState<string[]>([
    'solar_ar',
    'vortex_smg',
  ]);
  const [selectedMode, setSelectedMode] = useState<GameModeSpec>(GAME_MODES[0]);

  // Persistent Commander Progression State
  const [gold, setGold] = useState<number>(1450);
  const [gems, setGems] = useState<number>(240);
  const [rankRp, setRankRp] = useState<number>(3840);
  const [totalWins, setTotalWins] = useState<number>(14);
  const [totalKills, setTotalKills] = useState<number>(128);

  // Audio, Match & APK Studio Modal States
  const [soundOn, setSoundOn] = useState<boolean>(true);
  const [inBattle, setInBattle] = useState<boolean>(false);
  const [isDeploying, setIsDeploying] = useState<boolean>(false);
  const [apkModalOpen, setApkModalOpen] = useState<boolean>(false);
  const [testingWeaponId, setTestingWeaponId] = useState<string | null>(null);

  const t = UI_TEXT[lang];

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    soundEngine.enabled = next;
    if (next) soundEngine.playUiTick();
  };

  const toggleLang = () => {
    soundEngine.playUiTick();
    setLang((prev) => (prev === 'bn' ? 'en' : 'bn'));
  };

  const handleSelectTab = (tab: NavTab) => {
    soundEngine.playUiTick();
    setActiveTab(tab);
  };

  const cycleOperator = (dir: 1 | -1) => {
    soundEngine.playUiSelect();
    const idx = OPERATORS.findIndex((o) => o.id === selectedOperator.id);
    const nextIdx = (idx + dir + OPERATORS.length) % OPERATORS.length;
    setSelectedOperator(OPERATORS[nextIdx]);
  };

  const handleUnlockOrEquipWeapon = (w: WeaponSpec) => {
    if (unlockedWeapons.includes(w.id)) {
      soundEngine.playUiSelect();
      setSelectedWeapon(w);
      return;
    }
    if (gold >= w.unlockCost) {
      soundEngine.playVictory();
      setGold((g) => g - w.unlockCost);
      setUnlockedWeapons((prev) => [...prev, w.id]);
      setSelectedWeapon(w);
    }
  };

  const handleTestFireWeapon = (w: WeaponSpec) => {
    soundEngine.playGunshot(w.category);
    setTestingWeaponId(w.id);
    setTimeout(() => setTestingWeaponId(null), 260);
  };

  const handleStartBattle = () => {
    soundEngine.playDropDeploy();
    setIsDeploying(true);
    setTimeout(() => {
      setIsDeploying(false);
      setInBattle(true);
    }, 650);
  };

  const handleExitMatch = (
    rewardGold: number,
    rewardGems: number,
    killsEarned: number,
    won: boolean
  ) => {
    setInBattle(false);
    setGold((g) => g + rewardGold);
    setGems((gm) => gm + rewardGems);
    setTotalKills((k) => k + killsEarned);
    if (won) {
      setTotalWins((w) => w + 1);
      setRankRp((rp) => rp + 52);
    } else {
      setRankRp((rp) => rp + Math.max(8, killsEarned * 9));
    }
  };

  // Active 60FPS Battle Royale Match Screen
  if (inBattle) {
    return (
      <BattleArena
        operator={selectedOperator}
        primaryWeapon={selectedWeapon}
        mode={selectedMode}
        lang={lang}
        onExitMatch={handleExitMatch}
      />
    );
  }

  return (
    <div className="relative min-h-screen w-full bg-[#070A10] text-[#F8FAFC] overflow-hidden flex flex-col justify-between">
      {/* ====================================================================
          CINEMATIC 3D HANGAR BACKGROUND LAYER WITH ATMOSPHERIC VIGNETTE
          ==================================================================== */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <img
          src={lobbyBgImg}
          alt="Orbital Command Deck"
          className="w-full h-full object-cover object-center scale-[1.02] opacity-65"
        />
        {/* Radial vignette keeping center theatrical & edges ultra-high-contrast for glass HUD */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(circle at 50% 45%, rgba(7,10,16,0.22) 0%, rgba(7,10,16,0.72) 68%, rgba(7,10,16,0.95) 100%)',
          }}
        />
        {/* Subtle bottom obsidian floor blend */}
        <div className="absolute inset-x-0 bottom-0 h-44 bg-gradient-to-t from-[#070A10] via-[#070A10]/75 to-transparent" />
      </div>

      {/* ====================================================================
          TOP FLOATING SELECTIVE-GLASS COMMAND BAR
          ==================================================================== */}
      <header className="relative z-20 px-3 sm:px-6 pt-3 sm:pt-4 flex items-center justify-between gap-3 flex-wrap">
        {/* Left: Commander Profile & Rank Crest Capsule */}
        <div className="glass-capsule rounded-2xl px-3.5 py-2 flex items-center gap-3.5">
          <div className="relative">
            <img
              src={appIconImg}
              alt="Apex Eclipse Crest"
              className="w-10 h-10 rounded-xl object-cover border border-amber-400/50"
            />
            <span className="absolute -bottom-1 -right-1 px-1.5 py-0.2 rounded bg-amber-500 text-slate-950 font-mono-tech font-bold text-[9px]">
              64
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-sm sm:text-base tracking-wide text-white">
                APEX // COMMANDER
              </span>
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono-tech bg-amber-500/15 text-amber-300 border border-amber-500/30">
                <Award className="w-3 h-3" />
                {t.rankTitle}
              </span>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono-tech mt-0.5">
              <span>RP {rankRp}</span>
              <span className="text-slate-600">•</span>
              <span className="text-emerald-400">{totalWins} WINS</span>
              <span className="hidden md:inline text-slate-600">•</span>
              <span className="hidden md:inline text-cyan-400">{totalKills} KILLS</span>
            </div>
          </div>
        </div>

        {/* Right: Economy Telemetry, APK GitHub Studio Trigger, Lang & Audio */}
        <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap">
          {/* Currency Capsule */}
          <div className="glass-capsule rounded-xl px-3.5 py-2 flex items-center gap-3.5">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_8px_#FBBF24]" />
              <span className="font-mono-tech font-bold text-xs sm:text-sm text-amber-300">
                {gold.toLocaleString()}
              </span>
            </div>
            <div className="w-px h-4 bg-white/10" />
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rotate-45 bg-cyan-400 shadow-[0_0_8px_#00E5FF]" />
              <span className="font-mono-tech font-bold text-xs sm:text-sm text-cyan-300">
                {gems}
              </span>
            </div>
          </div>

          {/* Dedicated APK & GitHub Release Studio Button */}
          <button
            onClick={() => {
              soundEngine.playUiSelect();
              setApkModalOpen(true);
            }}
            className="glass-capsule hover:border-cyan-400/60 rounded-xl px-3.5 py-2 flex items-center gap-2 text-xs sm:text-sm font-display font-bold tracking-wide text-cyan-300 hover:text-white transition cursor-pointer shadow-[0_0_24px_rgba(0,229,255,0.16)]"
          >
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <span>{t.apkStudio}</span>
            <span className="hidden md:inline-flex px-1.5 py-0.5 text-[9px] font-mono-tech rounded bg-cyan-500/20 text-cyan-200 border border-cyan-400/30">
              .APK
            </span>
          </button>

          {/* Language Toggle (বাংলা | EN) */}
          <button
            onClick={toggleLang}
            className="glass-subtle hover:border-white/25 rounded-xl px-3 py-2 text-xs font-bold text-slate-200 hover:text-amber-300 transition cursor-pointer"
          >
            {lang === 'bn' ? 'EN' : 'বাংলা'}
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className="glass-subtle hover:border-white/25 rounded-xl p-2 text-slate-300 hover:text-white transition cursor-pointer"
            title="Toggle Tactical Audio"
          >
            {soundOn ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Live Server Ping Indicator */}
          <div className="hidden xl:flex glass-subtle rounded-xl px-2.5 py-2 items-center gap-1.5 text-[11px] font-mono-tech text-emerald-400">
            <Wifi className="w-3.5 h-3.5" />
            <span>16ms</span>
          </div>
        </div>
      </header>

      {/* ====================================================================
          MAIN STAGE AREA (LEFT NAV RAIL + DYNAMIC VIEWPORT)
          ==================================================================== */}
      <main className="relative z-10 flex-1 px-3 sm:px-6 py-4 flex flex-col lg:flex-row items-stretch gap-5 max-w-[1440px] w-full mx-auto">
        {/* Left Compact Selective-Glass Navigation Rail */}
        <nav className="lg:w-52 shrink-0 flex lg:flex-col justify-between gap-2">
          <div className="glass-capsule rounded-2xl p-2 flex lg:flex-col gap-1.5 w-full overflow-x-auto">
            {(
              [
                { id: 'lobby', label: t.lobby, icon: Compass },
                { id: 'heroes', label: t.heroes, icon: Users },
                { id: 'armory', label: t.armory, icon: Crosshair },
                { id: 'map', label: t.mapIntel, icon: MapIcon },
              ] as const
            ).map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelectTab(item.id)}
                  className={`flex-1 lg:flex-none px-3.5 py-2.5 rounded-xl flex items-center gap-2.5 text-left font-display font-bold text-sm tracking-wide transition cursor-pointer whitespace-nowrap ${
                    active
                      ? 'bg-gradient-to-r from-amber-500/25 to-orange-500/10 text-amber-300 border border-amber-400/45 shadow-[inset_0_1px_0_rgba(255,255,255,0.2)]'
                      : 'text-slate-300 hover:text-white hover:bg-white/5 border border-transparent'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 ${active ? 'text-amber-400' : 'text-slate-400'}`}
                  />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* GitHub APK Ready Card on Desktop Left Rail */}
          <div className="hidden lg:flex obsidian-card rounded-2xl p-4 flex-col gap-2.5 border border-cyan-500/20">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono-tech uppercase tracking-widest text-cyan-400 flex items-center gap-1">
                <GitBranch className="w-3.5 h-3.5" />
                {t.apkQuickBadge}
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              {lang === 'bn'
                ? 'এক ক্লিকে Capacitor ও GitHub Actions ওয়ার্কফ্লো ডাউনলোড করে অটোমেটিক .apk রিলিজ করুন।'
                : 'Export ready-to-push GitHub Actions pipeline for automated Android .apk Releases.'}
            </p>
            <button
              onClick={() => {
                soundEngine.playUiSelect();
                setApkModalOpen(true);
              }}
              className="mt-1 py-2 px-3 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-400/35 text-xs font-semibold text-cyan-300 flex items-center justify-between cursor-pointer transition"
            >
              <span>{lang === 'bn' ? 'APK বিল্ডার খুলুন' : 'Open APK Studio'}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </nav>

        {/* ==================================================================
            TAB 1: COMMAND LOBBY (3D-STYLE HERO STAGE + FLOATING GLASS INSPECT)
            ================================================================== */}
        {activeTab === 'lobby' && (
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 items-center gap-6">
            {/* Center Hero Character Showcase */}
            <div className="lg:col-span-7 relative flex flex-col items-center justify-center min-h-[370px] sm:min-h-[460px]">
              {/* Ambient Volumetric Halo Behind Hero */}
              <div
                className="absolute w-72 h-72 sm:w-96 sm:h-96 rounded-full blur-3xl opacity-35 pointer-events-none transition-all duration-500"
                style={{ backgroundColor: selectedOperator.accentColor }}
              />

              {/* Glowing Holographic Pedestal Ring */}
              <div
                className="absolute bottom-3 w-64 sm:w-80 h-12 rounded-full border-2 animate-pulse-ring pointer-events-none"
                style={{
                  borderColor: selectedOperator.accentColor,
                  boxShadow: `0 0 35px ${selectedOperator.glowRgba}`,
                  transform: 'rotateX(72deg)',
                }}
              />

              {/* Seamless Radial-Feathered AAA Operator Render */}
              <div className="relative z-10 flex items-center justify-center">
                <button
                  onClick={() => cycleOperator(-1)}
                  className="glass-subtle p-2.5 rounded-full text-slate-300 hover:text-white hover:border-amber-400/50 transition cursor-pointer mr-1 sm:mr-3"
                  title={t.selectOperator}
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                <img
                  key={selectedOperator.id}
                  src={selectedOperator.image}
                  alt={selectedOperator.codename}
                  className="hero-render-mask w-[250px] sm:w-[320px] md:w-[355px] h-[340px] sm:h-[430px] object-cover object-top select-none pointer-events-none transition-all duration-500"
                />

                <button
                  onClick={() => cycleOperator(1)}
                  className="glass-subtle p-2.5 rounded-full text-slate-300 hover:text-white hover:border-amber-400/50 transition cursor-pointer ml-1 sm:ml-3"
                  title={t.selectOperator}
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* Floating Glass Operator Identity Pill */}
              <div className="relative z-20 -mt-6 glass-capsule rounded-2xl px-5 py-2.5 flex items-center gap-3.5">
                <span
                  className="px-2 py-0.5 rounded text-[10px] font-mono-tech font-bold text-slate-950"
                  style={{ backgroundColor: selectedOperator.accentColor }}
                >
                  {selectedOperator.tier}
                </span>
                <div>
                  <h1 className="font-display font-bold text-lg sm:text-xl tracking-wider text-white leading-none">
                    {selectedOperator.codename}
                  </h1>
                  <p className="text-xs text-slate-300 mt-0.5">
                    {lang === 'bn' ? selectedOperator.roleBn : selectedOperator.roleEn}
                  </p>
                </div>
              </div>
            </div>

            {/* Right Floating Loadout & Match Launch Stack */}
            <div className="lg:col-span-5 flex flex-col gap-4 justify-center">
              {/* Selective Glass Active Skill Capsule */}
              <div className="glass-capsule rounded-2xl p-4">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-mono-tech uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5" />
                    {t.activeSkill}
                  </span>
                  <span className="text-[11px] font-mono-tech text-slate-400">
                    CD: {selectedOperator.cooldownSec}s
                  </span>
                </div>
                <div className="font-display font-bold text-base text-white">
                  {lang === 'bn' ? selectedOperator.skillNameBn : selectedOperator.skillNameEn}
                </div>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  {lang === 'bn' ? selectedOperator.skillDescBn : selectedOperator.skillDescEn}
                </p>
              </div>

              {/* Equipped Evo Mythic Weapon Card (Solid Obsidian Contrast) */}
              <div
                onClick={() => handleSelectTab('armory')}
                className="obsidian-card hover:border-amber-400/45 rounded-2xl p-4 cursor-pointer transition group"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-mono-tech uppercase tracking-wider text-cyan-400">
                    {t.equippedWeapon} • {selectedWeapon.rarity}
                  </span>
                  <span className="text-xs text-slate-400 group-hover:text-amber-300 flex items-center gap-0.5 transition">
                    {lang === 'bn' ? 'পরিবর্তন' : 'Change'}
                    <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>

                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-display font-bold text-lg text-white">
                      {selectedWeapon.name}
                    </div>
                    <div className="text-xs text-amber-300/90">
                      {lang === 'bn' ? selectedWeapon.skinTitleBn : selectedWeapon.skinTitleEn}
                    </div>
                  </div>
                  <WeaponArtwork
                    weaponId={selectedWeapon.id}
                    accent={selectedWeapon.accent}
                    className="w-36 h-14 shrink-0 group-hover:scale-105 transition-transform"
                  />
                </div>
              </div>

              {/* Battle Mode Selector + Chamfered Primary Match Launch CTA */}
              <div className="glass-capsule rounded-2xl p-4 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono-tech uppercase tracking-wider text-slate-400">
                    {lang === 'bn' ? 'সিলেক্টেড ব্যাটেল মোড' : 'BATTLE ROYALE MODE'}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono-tech font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {selectedMode.badge}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-1.5">
                  {GAME_MODES.map((m) => {
                    const isSelected = selectedMode.id === m.id;
                    return (
                      <button
                        key={m.id}
                        onClick={() => {
                          soundEngine.playUiTick();
                          setSelectedMode(m);
                        }}
                        className={`px-2.5 py-2 rounded-xl text-left transition cursor-pointer border ${
                          isSelected
                            ? 'bg-white/10 border-amber-400/60 text-white'
                            : 'bg-[#080C14]/70 border-white/5 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <div className="font-display font-bold text-xs truncate">
                          {lang === 'bn' ? m.nameBn.split(' ')[0] : m.nameEn.split(' ')[0]}
                        </div>
                        <div className="text-[10px] font-mono-tech text-slate-400">
                          {m.playersCount}P
                        </div>
                      </button>
                    );
                  })}
                </div>

                <div className="text-xs text-slate-300">
                  {lang === 'bn' ? selectedMode.subBn : selectedMode.subEn}
                </div>

                {/* Iconic Molten Amber Chamfered Battle CTA */}
                <button
                  onClick={handleStartBattle}
                  disabled={isDeploying}
                  className="relative overflow-hidden btn-shimmer w-full py-4 chamfer-btn bg-gradient-to-r from-[#FF9E0B] via-[#FF6A00] to-[#FF4D00] hover:brightness-110 active:scale-[0.99] text-slate-950 font-display font-bold text-xl tracking-wider uppercase flex items-center justify-center gap-2.5 cursor-pointer transition shadow-[0_14px_38px_rgba(255,110,0,0.42)]"
                >
                  <Play className="w-5 h-5 fill-slate-950" />
                  <span>{isDeploying ? t.deploying : t.startMatch}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ==================================================================
            TAB 2: OPERATORS SHOWCASE & ABILITY TELEMETRY
            ================================================================== */}
        {activeTab === 'heroes' && (
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative">
                <div
                  className="absolute inset-8 rounded-full blur-3xl opacity-35 pointer-events-none"
                  style={{ backgroundColor: selectedOperator.accentColor }}
                />
                <img
                  src={selectedOperator.image}
                  alt={selectedOperator.codename}
                  className="hero-render-mask w-[280px] sm:w-[340px] h-[390px] object-cover object-top relative z-10"
                />
              </div>
            </div>

            <div className="lg:col-span-7 flex flex-col gap-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {OPERATORS.map((op) => {
                  const active = op.id === selectedOperator.id;
                  return (
                    <button
                      key={op.id}
                      onClick={() => {
                        soundEngine.playUiSelect();
                        setSelectedOperator(op);
                      }}
                      className={`p-3.5 rounded-2xl text-left transition cursor-pointer ${
                        active ? 'obsidian-card-active' : 'obsidian-card hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span
                          className="text-[10px] font-mono-tech px-2 py-0.5 rounded font-bold text-slate-950"
                          style={{ backgroundColor: op.accentColor }}
                        >
                          {op.tier}
                        </span>
                        {active && <Check className="w-4 h-4 text-amber-400" />}
                      </div>
                      <div className="font-display font-bold text-base text-white">
                        {op.codename}
                      </div>
                      <div className="text-xs text-slate-400">
                        {lang === 'bn' ? op.roleBn : op.roleEn}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Detailed Selected Operator Glass Dossier */}
              <div className="glass-capsule rounded-2xl p-5 flex flex-col gap-4">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <h2 className="font-display text-2xl font-bold text-white">
                      {selectedOperator.codename}
                    </h2>
                    <p className="text-xs text-slate-400">
                      {lang === 'bn' ? selectedOperator.passiveBn : selectedOperator.passiveEn}
                    </p>
                  </div>
                  <button
                    onClick={() => handleSelectTab('lobby')}
                    className="px-4 py-2 chamfer-sm bg-amber-500 text-slate-950 font-display font-bold text-sm cursor-pointer"
                  >
                    {lang === 'bn' ? 'ডিপ্লয় লবিতে যান' : 'READY IN LOBBY'}
                  </button>
                </div>

                <div className="obsidian-card rounded-xl p-3.5 border border-white/10">
                  <div className="text-xs font-mono-tech text-amber-400 mb-1">
                    [E] {lang === 'bn' ? selectedOperator.skillNameBn : selectedOperator.skillNameEn}
                  </div>
                  <p className="text-xs sm:text-sm text-slate-300">
                    {lang === 'bn' ? selectedOperator.skillDescBn : selectedOperator.skillDescEn}
                  </p>
                </div>

                {/* Crisp Combat Attribute Bars */}
                <div className="grid grid-cols-2 gap-3">
                  {(
                    [
                      { label: lang === 'bn' ? 'গতি (Mobility)' : 'Mobility', val: selectedOperator.stats.mobility },
                      { label: lang === 'bn' ? 'ফায়ারপাওয়ার' : 'Firepower', val: selectedOperator.stats.firepower },
                      { label: lang === 'bn' ? 'ডিফেন্স শিল্ড' : 'Defense', val: selectedOperator.stats.defense },
                      { label: lang === 'bn' ? 'ট্যাকটিক্যাল টেক' : 'Cyber Tech', val: selectedOperator.stats.tech },
                    ] as const
                  ).map((st) => (
                    <div key={st.label}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-slate-400">{st.label}</span>
                        <span className="font-mono-tech text-white">{st.val}</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-slate-900 overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-300"
                          style={{
                            width: `${st.val}%`,
                            backgroundColor: selectedOperator.accentColor,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ==================================================================
            TAB 3: EVO MYTHIC ARMORY (SOLID OBSIDIAN CARDS + SOUND TEST FIRE)
            ================================================================== */}
        {activeTab === 'armory' && (
          <div className="flex-1 flex flex-col gap-4 justify-center">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h2 className="font-display text-2xl sm:text-3xl font-bold text-white flex items-center gap-2">
                  <Flame className="w-6 h-6 text-amber-400" />
                  {lang === 'bn'
                    ? 'ইভো মিথিক অস্ত্রাগার (EVO ARMORY)'
                    : 'EVO MYTHIC WEAPON ARMORY'}
                </h2>
                <p className="text-xs sm:text-sm text-slate-400">
                  {lang === 'bn'
                    ? 'যেকোনো অস্ত্র টেস্ট-ফায়ার করে সাউন্ড শুনুন এবং গোল্ড দিয়ে আনলক ও ইকুইপ করুন'
                    : 'Test-fire ballistic audio & equip Evo Lv.7 Mythic weapons for your Battle Royale drop'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {WEAPONS.map((w) => {
                const isUnlocked = unlockedWeapons.includes(w.id);
                const isEquipped = selectedWeapon.id === w.id;
                const isTesting = testingWeaponId === w.id;

                return (
                  <div
                    key={w.id}
                    className={`rounded-2xl p-5 transition flex flex-col justify-between gap-4 ${
                      isEquipped ? 'obsidian-card-active' : 'obsidian-card'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span
                          className="text-[10px] font-mono-tech px-2 py-0.5 rounded font-bold text-slate-950"
                          style={{ backgroundColor: w.accent }}
                        >
                          {w.rarity}
                        </span>
                        <h3 className="font-display text-xl font-bold text-white mt-1.5">
                          {w.name}
                        </h3>
                        <p className="text-xs text-slate-400">
                          {lang === 'bn' ? w.skinTitleBn : w.skinTitleEn} •{' '}
                          {lang === 'bn' ? w.categoryLabelBn : w.categoryLabelEn}
                        </p>
                      </div>

                      <button
                        onClick={() => handleTestFireWeapon(w)}
                        className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono-tech text-slate-300 hover:text-amber-300 cursor-pointer transition"
                      >
                        {lang === 'bn' ? '🔊 টেস্ট ফায়ার' : '🔊 TEST FIRE'}
                      </button>
                    </div>

                    {/* Vector Sci-Fi Weapon Showcase */}
                    <div
                      className={`py-2 flex items-center justify-center transition-transform duration-150 ${
                        isTesting ? '-translate-x-2 scale-105' : ''
                      }`}
                    >
                      <WeaponArtwork weaponId={w.id} accent={w.accent} className="w-64 h-20" />
                    </div>

                    {/* Weapon Telemetry Bars */}
                    <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                      {(
                        [
                          { k: 'DMG', v: w.statsUi.damage },
                          { k: 'FIRE RATE', v: w.statsUi.rate },
                          { k: 'RANGE', v: w.statsUi.range },
                          { k: 'PRECISION', v: w.statsUi.precision },
                        ] as const
                      ).map((bar) => (
                        <div key={bar.k}>
                          <div className="flex justify-between text-[11px] font-mono-tech text-slate-400 mb-0.5">
                            <span>{bar.k}</span>
                            <span className="text-white">{bar.v}</span>
                          </div>
                          <div className="h-1.5 rounded-full bg-slate-900 overflow-hidden">
                            <div
                              className="h-full rounded-full"
                              style={{ width: `${bar.v}%`, backgroundColor: w.accent }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Equip or Unlock CTA */}
                    <button
                      onClick={() => handleUnlockOrEquipWeapon(w)}
                      className={`w-full py-2.5 rounded-xl font-display font-bold text-sm tracking-wider uppercase flex items-center justify-center gap-2 cursor-pointer transition ${
                        isEquipped
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : isUnlocked
                          ? 'bg-white/10 hover:bg-amber-500 hover:text-slate-950 text-white'
                          : gold >= w.unlockCost
                          ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-slate-950'
                          : 'bg-white/5 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      {isEquipped ? (
                        <>
                          <Check className="w-4 h-4" />
                          {lang === 'bn' ? 'ইকুইপ করা আছে' : 'EQUIPPED FOR BATTLE'}
                        </>
                      ) : isUnlocked ? (
                        <span>{lang === 'bn' ? 'ইকুইপ করুন' : 'EQUIP WEAPON'}</span>
                      ) : (
                        <>
                          <Lock className="w-4 h-4" />
                          <span>
                            {lang === 'bn'
                              ? `${w.unlockCost} GOLD দিয়ে আনলক করুন`
                              : `UNLOCK FOR ${w.unlockCost} GOLD`}
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ==================================================================
            TAB 4: SATELLITE MAP INTEL & DROP ZONES
            ================================================================== */}
        {activeTab === 'map' && (
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-7">
              <div className="glass-capsule rounded-2xl p-2.5 relative overflow-hidden">
                <img
                  src={mapEclipseImg}
                  alt="Eclipse Atoll Tactical Satellite Map"
                  className="w-full h-[320px] sm:h-[400px] object-cover rounded-xl"
                />
                {/* Tactical Hotspot Callouts */}
                <div className="absolute top-1/4 left-1/3 glass-capsule px-2.5 py-1 rounded-lg text-[11px] font-mono-tech text-amber-300 border border-amber-400/50">
                  ● SOLAR CORE [MYTHIC LOOT]
                </div>
                <div className="absolute bottom-1/4 right-1/4 glass-capsule px-2.5 py-1 rounded-lg text-[11px] font-mono-tech text-cyan-300 border border-cyan-400/50">
                  ● CYBER DOCKS [HIGH TIER]
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 flex flex-col gap-3.5">
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">
                {lang === 'bn' ? 'ইকলিপ্স অ্যাটল স্যাটেলাইট ম্যাপ' : 'ECLIPSE ATOLL // RECON'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {lang === 'bn'
                  ? 'ফ্রি ফায়ারের সাধারণ ম্যাপের থেকেও আধুনিক ও ট্যাকটিক্যালভাবে ডিজাইন করা ইকলিপ্স অ্যাটল—যেখানে সোলার এয়ারড্রপ, এথার গ্লু-কভার এবং শ্রিংকিং ইলেকট্রোম্যাগনেটিক জোন রয়েছে।'
                  : 'Engineered for high-stakes tactical firefights with orbital Evo Airdrops, curved Aether Gloo-Wall physics, and dynamic shrinking storm rings.'}
              </p>

              <div className="flex flex-col gap-2.5">
                {GAME_MODES.map((m) => {
                  const active = selectedMode.id === m.id;
                  return (
                    <button
                      key={m.id}
                      onClick={() => {
                        soundEngine.playUiSelect();
                        setSelectedMode(m);
                      }}
                      className={`p-4 rounded-xl text-left transition cursor-pointer ${
                        active ? 'obsidian-card-active' : 'obsidian-card hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-display font-bold text-base text-white">
                          {lang === 'bn' ? m.nameBn : m.nameEn}
                        </span>
                        <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded bg-white/10 text-amber-300">
                          {m.badge}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">
                        {lang === 'bn' ? m.subBn : m.subEn}
                      </p>
                    </button>
                  );
                })}
              </div>

              <button
                onClick={handleStartBattle}
                className="mt-1 py-3.5 chamfer-btn bg-gradient-to-r from-amber-500 to-orange-600 text-slate-950 font-display font-bold text-lg tracking-wider uppercase cursor-pointer"
              >
                {t.startMatch}
              </button>
            </div>
          </div>
        )}
      </main>

      {/* ====================================================================
          SUBTLE TACTICAL FOOTER TELEMETRY STRIP
          ==================================================================== */}
      <footer className="relative z-10 px-4 sm:px-6 pb-3 pt-1 flex items-center justify-between gap-3 text-[11px] text-slate-400 flex-wrap">
        <div className="flex items-center gap-2">
          <Shield className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>{t.controlsHint}</span>
        </div>
        <div className="font-mono-tech text-slate-500 flex items-center gap-2">
          <Sparkles className="w-3 h-3 text-cyan-400" />
          <span>APEX ECLIPSE ENGINE v2.4 • 60FPS SELECTIVE GLASS UI</span>
        </div>
      </footer>

      {/* ====================================================================
          APK & GITHUB RELEASES PACKAGING STUDIO MODAL
          ==================================================================== */}
      <ApkGithubModal
        isOpen={apkModalOpen}
        onClose={() => setApkModalOpen(false)}
        lang={lang}
      />
    </div>
  );
}

export default App;
