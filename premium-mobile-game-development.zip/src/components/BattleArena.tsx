import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Shield,
  Zap,
  HeartPulse,
  Crosshair,
  RotateCw,
  LogOut,
  Trophy,
  Skull,
  Smartphone,
  Award,
  Flame,
} from 'lucide-react';
import { GameModeSpec, Language, Operator, WeaponSpec, WEAPONS } from '../data/gameData';
import { soundEngine } from '../utils/soundEngine';
import { WeaponArtwork } from './WeaponArtwork';

interface BattleArenaProps {
  operator: Operator;
  primaryWeapon: WeaponSpec;
  mode: GameModeSpec;
  lang: Language;
  onExitMatch: (rewardGold: number, rewardGems: number, kills: number, won: boolean) => void;
}

interface Obstacle {
  x: number;
  y: number;
  w: number;
  h: number;
  kind: 'building' | 'crate' | 'pillar';
  color: string;
}

interface LootItem {
  id: number;
  x: number;
  y: number;
  kind: 'medkit' | 'shield' | 'gloo' | 'airdrop';
  active: boolean;
}

interface GlooWall {
  id: number;
  x: number;
  y: number;
  angle: number;
  hp: number;
  maxHp: number;
  ownerId: string;
  color: string;
  createdAt: number;
}

interface Bullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  rangeLeft: number;
  ownerId: string;
  color: string;
  critChance: number;
  isSniper?: boolean;
}

interface BotEntity {
  id: string;
  name: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  hp: number;
  maxHp: number;
  shield: number;
  color: string;
  weapon: WeaponSpec;
  lastShot: number;
  strafeDir: number;
  strafeTimer: number;
  glooCooldown: number;
  alive: boolean;
}

interface FloatingText {
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  scale: number;
  alpha: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  alpha: number;
  decay: number;
}

interface Shockwave {
  x: number;
  y: number;
  r: number;
  maxR: number;
  color: string;
  alpha: number;
}

interface KillFeedItem {
  id: number;
  killer: string;
  victim: string;
  weaponName: string;
  isCrit: boolean;
  isPlayer: boolean;
}

const BOT_NAMES = [
  'ShadowBD_99',
  'DhakaSniper',
  'NyxVortex',
  'CyberRiot_X',
  'AetherKing',
  'PhantomZero',
  'Bengal Tiger',
  'KaelStorm',
  'NovaStrike',
  'SolarFury',
  'CrimsonEvo',
  'FrostByte7',
  'ApexReaper',
  'GlooMaster',
  'TitanSlayer',
  'ValkyriePro',
  'Zenith_OP',
  'BlitzKrieg',
  'OmegaPulse',
];

export const BattleArena: React.FC<BattleArenaProps> = ({
  operator,
  primaryWeapon,
  mode,
  lang,
  onExitMatch,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const minimapRef = useRef<HTMLCanvasElement | null>(null);

  // Secondary backup weapon (different from primary)
  const secondaryWeapon =
    primaryWeapon.id === 'vortex_smg' ? WEAPONS[0] : WEAPONS[1];

  // React HUD states (updated throttled for 60FPS smoothness)
  const [hp, setHp] = useState(100);
  const [shield, setShield] = useState(operator.id === 'titan' ? 140 : 100);
  const maxShield = operator.id === 'titan' ? 140 : 100;
  const [ammo, setAmmo] = useState(primaryWeapon.magSize);
  const [isReloading, setIsReloading] = useState(false);
  const [activeSlot, setActiveSlot] = useState<0 | 1>(0);
  const [glooCount, setGlooCount] = useState(4);
  const [medkitCount, setMedkitCount] = useState(3);
  const [skillCooldown, setSkillCooldown] = useState(0);
  const [skillActiveLeft, setSkillActiveLeft] = useState(0);
  const [aliveCount, setAliveCount] = useState(mode.playersCount);
  const [kills, setKills] = useState(0);
  const [damageDealt, setDamageDealt] = useState(0);
  const [headshots, setHeadshots] = useState(0);
  const [zoneTimer, setZoneTimer] = useState(35);
  const [killFeed, setKillFeed] = useState<KillFeedItem[]>([]);
  const [streakBanner, setStreakBanner] = useState<string | null>(null);
  const [showTouchHud, setShowTouchHud] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return 'ontouchstart' in window || window.innerWidth < 960;
    }
    return false;
  });
  const [matchResult, setMatchResult] = useState<{
    finished: boolean;
    won: boolean;
    placement: number;
  } | null>(null);

  // Mutable simulation state inside ref for zero-lag 60fps loop
  const simRef = useRef({
    worldSize: mode.mapSize,
    player: {
      x: mode.mapSize / 2 + (Math.random() - 0.5) * 260,
      y: mode.mapSize / 2 + (Math.random() - 0.5) * 260,
      vx: 0,
      vy: 0,
      angle: 0,
      hp: 100,
      maxHp: 100,
      shield: operator.id === 'titan' ? 140 : 100,
      maxShield: operator.id === 'titan' ? 140 : 100,
      slot: 0 as 0 | 1,
      mags: [primaryWeapon.magSize, secondaryWeapon.magSize],
      reloadingUntil: 0,
      lastShot: 0,
      glooCharges: 4,
      medkits: 3,
      skillReadyAt: 0,
      skillActiveUntil: 0,
      dashReadyAt: 0,
      damageBoost: 1,
      alive: true,
    },
    keys: {} as Record<string, boolean>,
    mouse: { x: 0, y: 0, down: false, worldX: 0, worldY: 0 },
    touchMove: { active: false, dx: 0, dy: 0, id: -1, originX: 0, originY: 0 },
    touchAim: { active: false, dx: 0, dy: 0, firing: false, id: -1, originX: 0, originY: 0 },
    obstacles: [] as Obstacle[],
    loots: [] as LootItem[],
    glooWalls: [] as GlooWall[],
    bullets: [] as Bullet[],
    bots: [] as BotEntity[],
    texts: [] as FloatingText[],
    particles: [] as Particle[],
    shockwaves: [] as Shockwave[],
    zone: {
      x: mode.mapSize / 2,
      y: mode.mapSize / 2,
      radius: mode.mapSize * 0.66,
      minRadius: 210,
      shrinkRate: 14 * mode.stormSpeed,
    },
    stats: {
      kills: 0,
      damage: 0,
      headshots: 0,
    },
    finished: false,
  });

  // Trigger Actions (callable from Keyboard OR Touch Glass HUD)
  const deployGlooWall = useCallback(() => {
    const sim = simRef.current;
    if (!sim.player.alive || sim.finished) return;
    if (sim.player.glooCharges <= 0) return;
    sim.player.glooCharges -= 1;
    setGlooCount(sim.player.glooCharges);

    const dist = 74;
    const gx = sim.player.x + Math.cos(sim.player.angle) * dist;
    const gy = sim.player.y + Math.sin(sim.player.angle) * dist;

    sim.glooWalls.push({
      id: Date.now() + Math.random(),
      x: gx,
      y: gy,
      angle: sim.player.angle,
      hp: 260,
      maxHp: 260,
      ownerId: 'player',
      color: '#00E5FF',
      createdAt: performance.now(),
    });
    sim.shockwaves.push({
      x: gx,
      y: gy,
      r: 8,
      maxR: 65,
      color: '#00E5FF',
      alpha: 0.85,
    });
    soundEngine.playShieldDeploy();
  }, []);

  const triggerOperatorSkill = useCallback(() => {
    const sim = simRef.current;
    const now = performance.now();
    if (!sim.player.alive || sim.finished) return;
    if (now < sim.player.skillReadyAt) return;

    const durationMs = operator.id === 'phantom' ? 4500 : 5000;
    sim.player.skillActiveUntil = now + durationMs;
    sim.player.skillReadyAt = now + operator.cooldownSec * 1000;

    if (operator.id === 'titan') {
      sim.player.shield = Math.min(sim.player.maxShield, sim.player.shield + 65);
      setShield(Math.round(sim.player.shield));
    }

    sim.shockwaves.push({
      x: sim.player.x,
      y: sim.player.y,
      r: 12,
      maxR: operator.id === 'valkyrie' ? 520 : 160,
      color: operator.accentColor,
      alpha: 0.95,
    });

    sim.texts.push({
      x: sim.player.x,
      y: sim.player.y - 36,
      vy: -1.3,
      text: lang === 'bn' ? operator.skillNameBn : operator.skillNameEn.toUpperCase(),
      color: operator.accentColor,
      scale: 1.15,
      alpha: 1,
    });

    soundEngine.playShieldDeploy();
  }, [operator, lang]);

  const useMedkit = useCallback(() => {
    const sim = simRef.current;
    if (!sim.player.alive || sim.finished) return;
    if (sim.player.medkits <= 0 || sim.player.hp >= sim.player.maxHp) return;
    sim.player.medkits -= 1;
    sim.player.hp = Math.min(sim.player.maxHp, sim.player.hp + 55);
    setMedkitCount(sim.player.medkits);
    setHp(Math.round(sim.player.hp));
    soundEngine.playHeal();

    for (let i = 0; i < 14; i++) {
      const a = (Math.PI * 2 * i) / 14;
      sim.particles.push({
        x: sim.player.x,
        y: sim.player.y,
        vx: Math.cos(a) * 2.5,
        vy: Math.sin(a) * 2.5,
        radius: 3.5,
        color: '#10B981',
        alpha: 1,
        decay: 0.03,
      });
    }
    sim.texts.push({
      x: sim.player.x,
      y: sim.player.y - 28,
      vy: -1.2,
      text: '+55 HP NANO-HEAL',
      color: '#10B981',
      scale: 1.05,
      alpha: 1,
    });
  }, []);

  const triggerReload = useCallback(() => {
    const sim = simRef.current;
    const now = performance.now();
    if (!sim.player.alive || sim.finished) return;
    const w = sim.player.slot === 0 ? primaryWeapon : secondaryWeapon;
    if (sim.player.mags[sim.player.slot] >= w.magSize || now < sim.player.reloadingUntil) return;
    const reloadDur = operator.id === 'phantom' ? w.reloadMs * 0.8 : w.reloadMs;
    sim.player.reloadingUntil = now + reloadDur;
    setIsReloading(true);
    soundEngine.playUiSelect();
  }, [primaryWeapon, secondaryWeapon, operator.id]);

  const swapWeapon = useCallback((slot?: 0 | 1) => {
    const sim = simRef.current;
    if (!sim.player.alive || sim.finished) return;
    const nextSlot: 0 | 1 = slot !== undefined ? slot : sim.player.slot === 0 ? 1 : 0;
    sim.player.slot = nextSlot;
    sim.player.reloadingUntil = 0;
    setIsReloading(false);
    setActiveSlot(nextSlot);
    setAmmo(sim.player.mags[nextSlot]);
    soundEngine.playUiTick();
  }, []);

  const triggerDash = useCallback(() => {
    const sim = simRef.current;
    const now = performance.now();
    if (!sim.player.alive || sim.finished || now < sim.player.dashReadyAt) return;
    sim.player.dashReadyAt = now + 2400;
    const moveAngle =
      Math.abs(sim.player.vx) + Math.abs(sim.player.vy) > 0.2
        ? Math.atan2(sim.player.vy, sim.player.vx)
        : sim.player.angle;
    sim.player.x += Math.cos(moveAngle) * 78;
    sim.player.y += Math.sin(moveAngle) * 78;
    sim.shockwaves.push({
      x: sim.player.x,
      y: sim.player.y,
      r: 6,
      maxR: 46,
      color: '#FF9E0B',
      alpha: 0.75,
    });
    soundEngine.playUiSelect();
  }, []);

  // Initialize World, Tactical Compounds, Loot & AI Bots
  useEffect(() => {
    const sim = simRef.current;
    const W = sim.worldSize;
    const obstacles: Obstacle[] = [];

    // Generate sleek cyber-compounds avoiding immediate spawn center
    const gridCount = Math.floor(W / 380);
    for (let gx = 1; gx < gridCount; gx++) {
      for (let gy = 1; gy < gridCount; gy++) {
        const cx = gx * 370 + (Math.random() - 0.5) * 90;
        const cy = gy * 370 + (Math.random() - 0.5) * 90;
        const distFromPlayer = Math.hypot(cx - sim.player.x, cy - sim.player.y);
        if (distFromPlayer < 170) continue;

        const roll = Math.random();
        if (roll < 0.45) {
          obstacles.push({
            x: cx - 65,
            y: cy - 38,
            w: 130,
            h: 76,
            kind: 'building',
            color: '#111927',
          });
        } else if (roll < 0.78) {
          obstacles.push({
            x: cx - 32,
            y: cy - 32,
            w: 64,
            h: 64,
            kind: 'crate',
            color: '#172236',
          });
        } else {
          obstacles.push({
            x: cx - 24,
            y: cy - 68,
            w: 48,
            h: 136,
            kind: 'pillar',
            color: '#131D2E',
          });
        }
      }
    }
    sim.obstacles = obstacles;

    // Generate Loot & Golden Mythic Airdrops
    const loots: LootItem[] = [];
    for (let i = 0; i < 34; i++) {
      const lx = 180 + Math.random() * (W - 360);
      const ly = 180 + Math.random() * (W - 360);
      const insideObs = obstacles.some(
        (o) => lx > o.x - 24 && lx < o.x + o.w + 24 && ly > o.y - 24 && ly < o.y + o.h + 24
      );
      if (insideObs) continue;
      const r = Math.random();
      loots.push({
        id: i,
        x: lx,
        y: ly,
        kind: r < 0.16 ? 'airdrop' : r < 0.48 ? 'medkit' : r < 0.76 ? 'shield' : 'gloo',
        active: true,
      });
    }
    sim.loots = loots;

    // Spawn Smart AI Survivors
    const bots: BotEntity[] = [];
    const botTotal = mode.playersCount - 1;
    for (let i = 0; i < botTotal; i++) {
      let bx = 200 + Math.random() * (W - 400);
      let by = 200 + Math.random() * (W - 400);
      // Ensure safe spawn distance from player
      if (Math.hypot(bx - sim.player.x, by - sim.player.y) < 380) {
        bx = Math.min(W - 180, bx + 420);
      }
      const wSpec = WEAPONS[i % WEAPONS.length];
      bots.push({
        id: `bot_${i}`,
        name: BOT_NAMES[i % BOT_NAMES.length],
        x: bx,
        y: by,
        vx: 0,
        vy: 0,
        angle: Math.random() * Math.PI * 2,
        hp: 100,
        maxHp: 100,
        shield: 55,
        color: i % 3 === 0 ? '#F43F5E' : i % 3 === 1 ? '#FB923C' : '#A855F7',
        weapon: wSpec,
        lastShot: 0,
        strafeDir: Math.random() > 0.5 ? 1 : -1,
        strafeTimer: 0,
        glooCooldown: 0,
        alive: true,
      });
    }
    sim.bots = bots;

    soundEngine.playDropDeploy();
  }, [mode.playersCount]);

  // Keyboard & Mouse Listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      simRef.current.keys[k] = true;
      if (k === 'q') deployGlooWall();
      if (k === 'e') triggerOperatorSkill();
      if (k === 'h') useMedkit();
      if (k === 'r') triggerReload();
      if (k === '1') swapWeapon(0);
      if (k === '2') swapWeapon(1);
      if (e.code === 'Space') {
        e.preventDefault();
        triggerDash();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      simRef.current.keys[e.key.toLowerCase()] = false;
    };
    const handleMouseMove = (e: MouseEvent) => {
      simRef.current.mouse.x = e.clientX;
      simRef.current.mouse.y = e.clientY;
    };
    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 0) simRef.current.mouse.down = true;
    };
    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) simRef.current.mouse.down = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [deployGlooWall, triggerOperatorSkill, useMedkit, triggerReload, swapWeapon, triggerDash]);

  // Helper collision check
  const resolveCircleRect = (cx: number, cy: number, r: number, obs: Obstacle[]) => {
    let nx = cx;
    let ny = cy;
    for (const o of obs) {
      const closestX = Math.max(o.x, Math.min(nx, o.x + o.w));
      const closestY = Math.max(o.y, Math.min(ny, o.y + o.h));
      const dx = nx - closestX;
      const dy = ny - closestY;
      const distSq = dx * dx + dy * dy;
      if (distSq < r * r) {
        const dist = Math.sqrt(distSq) || 0.001;
        const overlap = r - dist;
        nx += (dx / dist) * overlap;
        ny += (dy / dist) * overlap;
      }
    }
    return { x: nx, y: ny };
  };

  // Main 60FPS Game Loop
  useEffect(() => {
    let rafId = 0;
    let lastTime = performance.now();
    let uiSyncAccumulator = 0;

    const pushKillFeed = (
      killer: string,
      victim: string,
      weaponName: string,
      isCrit: boolean,
      isPlayer: boolean
    ) => {
      setKillFeed((prev) => [
        { id: Date.now() + Math.random(), killer, victim, weaponName, isCrit, isPlayer },
        ...prev.slice(0, 3),
      ]);
    };

    const fireWeapon = (
      shooterId: string,
      sx: number,
      sy: number,
      angle: number,
      weapon: WeaponSpec,
      dmgMult: number,
      extraCrit: number,
      color: string
    ) => {
      const sim = simRef.current;
      const speedBonus = shooterId === 'player' && operator.id === 'valkyrie' ? 1.15 : 1;
      for (let p = 0; p < weapon.pellets; p++) {
        const spread = (Math.random() - 0.5) * weapon.spreadRad * 2;
        const finalAngle = angle + spread;
        sim.bullets.push({
          x: sx + Math.cos(finalAngle) * 26,
          y: sy + Math.sin(finalAngle) * 26,
          vx: Math.cos(finalAngle) * weapon.bulletSpeed * speedBonus,
          vy: Math.sin(finalAngle) * weapon.bulletSpeed * speedBonus,
          damage: weapon.damage * dmgMult,
          rangeLeft: weapon.rangePx,
          ownerId: shooterId,
          color,
          critChance: weapon.critChance + extraCrit,
          isSniper: weapon.category === 'sniper',
        });
      }
      // Muzzle flash particles
      for (let i = 0; i < 4; i++) {
        const ma = angle + (Math.random() - 0.5) * 0.5;
        sim.particles.push({
          x: sx + Math.cos(angle) * 25,
          y: sy + Math.sin(angle) * 25,
          vx: Math.cos(ma) * (3 + Math.random() * 3),
          vy: Math.sin(ma) * (3 + Math.random() * 3),
          radius: 2.6,
          color,
          alpha: 0.95,
          decay: 0.09,
        });
      }
      if (shooterId === 'player') {
        soundEngine.playGunshot(weapon.category);
      }
    };

    const step = (now: number) => {
      const dt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;

      const canvas = canvasRef.current;
      if (!canvas) {
        rafId = requestAnimationFrame(step);
        return;
      }
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Resize canvas cleanly to viewport DPR
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      if (canvas.width !== Math.floor(vw * dpr) || canvas.height !== Math.floor(vh * dpr)) {
        canvas.width = Math.floor(vw * dpr);
        canvas.height = Math.floor(vh * dpr);
      }

      const sim = simRef.current;
      const p = sim.player;
      const curWeapon = p.slot === 0 ? primaryWeapon : secondaryWeapon;
      const skillActive = now < p.skillActiveUntil;

      if (!sim.finished) {
        // 1. Check Reload completion
        if (p.reloadingUntil > 0 && now >= p.reloadingUntil) {
          p.reloadingUntil = 0;
          p.mags[p.slot] = curWeapon.magSize;
          setIsReloading(false);
          setAmmo(curWeapon.magSize);
        }

        // 2. Player Movement
        if (p.alive) {
          let mx = 0;
          let my = 0;
          if (sim.keys['w'] || sim.keys['arrowup']) my -= 1;
          if (sim.keys['s'] || sim.keys['arrowdown']) my += 1;
          if (sim.keys['a'] || sim.keys['arrowleft']) mx -= 1;
          if (sim.keys['d'] || sim.keys['arrowright']) mx += 1;

          if (sim.touchMove.active) {
            mx += sim.touchMove.dx;
            my += sim.touchMove.dy;
          }

          const len = Math.hypot(mx, my);
          if (len > 0.01) {
            mx /= Math.max(1, len);
            my /= Math.max(1, len);
          }

          let baseSpeed = 245;
          if (operator.id === 'phantom') baseSpeed *= 1.12;
          if (skillActive && operator.id === 'phantom') baseSpeed *= 1.38;

          p.vx = mx * baseSpeed;
          p.vy = my * baseSpeed;

          const nextPos = resolveCircleRect(
            Math.max(40, Math.min(sim.worldSize - 40, p.x + p.vx * dt)),
            Math.max(40, Math.min(sim.worldSize - 40, p.y + p.vy * dt)),
            20,
            sim.obstacles
          );
          p.x = nextPos.x;
          p.y = nextPos.y;

          // Aim angle
          if (sim.touchAim.active && (Math.abs(sim.touchAim.dx) > 0.1 || Math.abs(sim.touchAim.dy) > 0.1)) {
            p.angle = Math.atan2(sim.touchAim.dy, sim.touchAim.dx);
          } else if (!sim.touchMove.active) {
            const camX = p.x - vw / 2;
            const camY = p.y - vh / 2;
            p.angle = Math.atan2(sim.mouse.y + camY - p.y, sim.mouse.x + camX - p.x);
          } else if (len > 0.15) {
            p.angle = Math.atan2(my, mx);
          }

          // Shooting
          const wantsFire = sim.mouse.down || sim.touchAim.firing;
          const fireInterval =
            skillActive && operator.id === 'phantom'
              ? curWeapon.fireRateMs * 0.68
              : curWeapon.fireRateMs;

          if (wantsFire && p.reloadingUntil === 0 && now - p.lastShot >= fireInterval) {
            if (p.mags[p.slot] > 0) {
              p.lastShot = now;
              p.mags[p.slot] -= 1;
              setAmmo(p.mags[p.slot]);
              const extraCrit = skillActive && operator.id === 'valkyrie' ? 0.4 : 0;
              fireWeapon(
                'player',
                p.x,
                p.y,
                p.angle,
                curWeapon,
                p.damageBoost,
                extraCrit,
                curWeapon.accent
              );
              if (p.mags[p.slot] === 0) {
                triggerReload();
              }
            } else {
              triggerReload();
            }
          }

          // Loot Pickup Check
          for (const item of sim.loots) {
            if (!item.active) continue;
            if (Math.hypot(item.x - p.x, item.y - p.y) < 38) {
              item.active = false;
              soundEngine.playUiSelect();
              if (item.kind === 'medkit') {
                p.medkits += 1;
                setMedkitCount(p.medkits);
                sim.texts.push({
                  x: item.x,
                  y: item.y - 12,
                  vy: -1,
                  text: '+1 NANO MEDKIT',
                  color: '#10B981',
                  scale: 0.95,
                  alpha: 1,
                });
              } else if (item.kind === 'shield') {
                p.shield = Math.min(p.maxShield, p.shield + 45);
                setShield(Math.round(p.shield));
                sim.texts.push({
                  x: item.x,
                  y: item.y - 12,
                  vy: -1,
                  text: '+45 ARMOR SHIELD',
                  color: '#38BDF8',
                  scale: 0.95,
                  alpha: 1,
                });
              } else if (item.kind === 'gloo') {
                p.glooCharges += 2;
                setGlooCount(p.glooCharges);
                sim.texts.push({
                  x: item.x,
                  y: item.y - 12,
                  vy: -1,
                  text: '+2 AETHER WALL',
                  color: '#00E5FF',
                  scale: 0.95,
                  alpha: 1,
                });
              } else if (item.kind === 'airdrop') {
                p.damageBoost = Math.min(1.45, p.damageBoost + 0.18);
                p.shield = p.maxShield;
                p.hp = p.maxHp;
                p.glooCharges += 2;
                setGlooCount(p.glooCharges);
                setHp(p.hp);
                setShield(p.shield);
                sim.shockwaves.push({
                  x: item.x,
                  y: item.y,
                  r: 10,
                  maxR: 95,
                  color: '#FF9E0B',
                  alpha: 0.95,
                });
                sim.texts.push({
                  x: item.x,
                  y: item.y - 20,
                  vy: -1.3,
                  text: 'MYTHIC AIRDROP! +18% EVO DMG',
                  color: '#FF9E0B',
                  scale: 1.2,
                  alpha: 1,
                });
              }
            }
          }
        }

        // 3. Shrinking Aether Storm Zone
        if (sim.zone.radius > sim.zone.minRadius) {
          sim.zone.radius = Math.max(sim.zone.minRadius, sim.zone.radius - sim.zone.shrinkRate * dt);
        }
        // Storm Damage to Player
        if (p.alive && Math.hypot(p.x - sim.zone.x, p.y - sim.zone.y) > sim.zone.radius) {
          p.hp -= 7 * dt;
          if (p.hp <= 0) {
            p.hp = 0;
            p.alive = false;
            sim.finished = true;
            const aliveBots = sim.bots.filter((b) => b.alive).length;
            setMatchResult({ finished: true, won: false, placement: aliveBots + 1 });
          }
        }

        // 4. Update AI Bots
        for (const bot of sim.bots) {
          if (!bot.alive) continue;

          // Storm damage to bots
          const distZone = Math.hypot(bot.x - sim.zone.x, bot.y - sim.zone.y);
          if (distZone > sim.zone.radius) {
            bot.hp -= 8.5 * dt;
            if (bot.hp <= 0) {
              bot.alive = false;
              pushKillFeed('AETHER STORM', bot.name, 'ZONE', false, false);
              continue;
            }
          }

          // Find closest target (player or another bot)
          let targetX = sim.zone.x;
          let targetY = sim.zone.y;
          let targetDist = Infinity;
          let hasCombatTarget = false;

          if (p.alive) {
            const dp = Math.hypot(p.x - bot.x, p.y - bot.y);
            if (dp < 540) {
              targetDist = dp;
              targetX = p.x;
              targetY = p.y;
              hasCombatTarget = true;
            }
          }

          for (const other of sim.bots) {
            if (!other.alive || other.id === bot.id) continue;
            const d = Math.hypot(other.x - bot.x, other.y - bot.y);
            if (d < 460 && d < targetDist) {
              targetDist = d;
              targetX = other.x;
              targetY = other.y;
              hasCombatTarget = true;
            }
          }

          let moveAngle = Math.atan2(targetY - bot.y, targetX - bot.x);
          bot.strafeTimer -= dt;
          if (bot.strafeTimer <= 0) {
            bot.strafeTimer = 1.2 + Math.random() * 1.5;
            bot.strafeDir = Math.random() > 0.5 ? 1 : -1;
          }

          if (distZone > sim.zone.radius * 0.86) {
            // Prioritize running into safe zone
            moveAngle = Math.atan2(sim.zone.y - bot.y, sim.zone.x - bot.x);
          } else if (hasCombatTarget) {
            bot.angle = Math.atan2(targetY - bot.y, targetX - bot.x);
            if (targetDist < 240) {
              moveAngle = bot.angle + (Math.PI / 2) * bot.strafeDir;
            }
          } else {
            // Roam gracefully toward center
            moveAngle = Math.atan2(sim.zone.y - bot.y, sim.zone.x - bot.x) + bot.strafeDir * 0.7;
            bot.angle = moveAngle;
          }

          const botSpeed = 165;
          const nextBot = resolveCircleRect(
            Math.max(50, Math.min(sim.worldSize - 50, bot.x + Math.cos(moveAngle) * botSpeed * dt)),
            Math.max(50, Math.min(sim.worldSize - 50, bot.y + Math.sin(moveAngle) * botSpeed * dt)),
            19,
            sim.obstacles
          );
          bot.x = nextBot.x;
          bot.y = nextBot.y;

          // Bot tactical Gloo-Wall when hurt
          if (bot.hp < 45 && now > bot.glooCooldown && hasCombatTarget) {
            bot.glooCooldown = now + 14000;
            sim.glooWalls.push({
              id: now + Math.random(),
              x: bot.x + Math.cos(bot.angle) * 62,
              y: bot.y + Math.sin(bot.angle) * 62,
              angle: bot.angle,
              hp: 180,
              maxHp: 180,
              ownerId: bot.id,
              color: '#F43F5E',
              createdAt: now,
            });
          }

          // Bot shooting (moderated accuracy so gameplay feels heroic & fair)
          const botFireDelay = Math.max(360, bot.weapon.fireRateMs * 2.6);
          if (hasCombatTarget && targetDist < 480 && now - bot.lastShot > botFireDelay) {
            bot.lastShot = now;
            const aimJitter = (Math.random() - 0.5) * 0.22;
            fireWeapon(
              bot.id,
              bot.x,
              bot.y,
              bot.angle + aimJitter,
              bot.weapon,
              0.52,
              0.05,
              bot.color
            );
          }
        }

        // 5. Update Bullets & Collisions
        for (let i = sim.bullets.length - 1; i >= 0; i--) {
          const b = sim.bullets[i];
          b.x += b.vx;
          b.y += b.vy;
          const stepDist = Math.hypot(b.vx, b.vy);
          b.rangeLeft -= stepDist;

          if (
            b.rangeLeft <= 0 ||
            b.x < 0 ||
            b.x > sim.worldSize ||
            b.y < 0 ||
            b.y > sim.worldSize
          ) {
            sim.bullets.splice(i, 1);
            continue;
          }

          // Hit static obstacle?
          let hitWall = false;
          for (const o of sim.obstacles) {
            if (b.x >= o.x && b.x <= o.x + o.w && b.y >= o.y && b.y <= o.y + o.h) {
              hitWall = true;
              break;
            }
          }
          if (hitWall) {
            for (let s = 0; s < 3; s++) {
              sim.particles.push({
                x: b.x,
                y: b.y,
                vx: (Math.random() - 0.5) * 4,
                vy: (Math.random() - 0.5) * 4,
                radius: 2,
                color: '#94A3B8',
                alpha: 0.8,
                decay: 0.08,
              });
            }
            sim.bullets.splice(i, 1);
            continue;
          }

          // Hit Aether Gloo-Wall?
          let hitGloo = false;
          for (let gIdx = sim.glooWalls.length - 1; gIdx >= 0; gIdx--) {
            const gw = sim.glooWalls[gIdx];
            if (gw.ownerId === b.ownerId) continue;
            // Line segment approx perpendicular to gw.angle
            const perpX = -Math.sin(gw.angle);
            const perpY = Math.cos(gw.angle);
            const dx = b.x - gw.x;
            const dy = b.y - gw.y;
            const along = dx * perpX + dy * perpY;
            const normal = dx * Math.cos(gw.angle) + dy * Math.sin(gw.angle);
            if (Math.abs(along) < 54 && Math.abs(normal) < 16) {
              gw.hp -= b.damage;
              hitGloo = true;
              for (let s = 0; s < 5; s++) {
                sim.particles.push({
                  x: b.x,
                  y: b.y,
                  vx: (Math.random() - 0.5) * 5,
                  vy: (Math.random() - 0.5) * 5,
                  radius: 2.5,
                  color: gw.color,
                  alpha: 1,
                  decay: 0.07,
                });
              }
              if (gw.hp <= 0) {
                sim.glooWalls.splice(gIdx, 1);
              }
              break;
            }
          }
          if (hitGloo) {
            sim.bullets.splice(i, 1);
            continue;
          }

          // Hit Player?
          if (b.ownerId !== 'player' && p.alive && Math.hypot(b.x - p.x, b.y - p.y) < 20) {
            let incoming = b.damage;
            if (skillActive && operator.id === 'titan') {
              incoming *= 0.45;
            }
            if (p.shield > 0) {
              const absorbed = Math.min(p.shield, incoming * 0.72);
              p.shield -= absorbed;
              incoming -= absorbed;
            }
            p.hp = Math.max(0, p.hp - incoming);
            sim.bullets.splice(i, 1);

            if (p.hp <= 0) {
              p.alive = false;
              sim.finished = true;
              const aliveBots = sim.bots.filter((bt) => bt.alive).length;
              setMatchResult({ finished: true, won: false, placement: aliveBots + 1 });
            }
            continue;
          }

          // Hit AI Bot?
          for (const bot of sim.bots) {
            if (!bot.alive || bot.id === b.ownerId) continue;
            if (Math.hypot(b.x - bot.x, b.y - bot.y) < 21) {
              const isCrit = Math.random() < b.critChance;
              const finalDmg = Math.round(b.damage * (isCrit ? 1.65 : 1));
              let rem = finalDmg;
              if (bot.shield > 0) {
                const abs = Math.min(bot.shield, rem * 0.6);
                bot.shield -= abs;
                rem -= abs;
              }
              bot.hp -= rem;

              if (b.ownerId === 'player') {
                sim.stats.damage += finalDmg;
                soundEngine.playHitmarker(isCrit);
                sim.texts.push({
                  x: bot.x + (Math.random() - 0.5) * 18,
                  y: bot.y - 24,
                  vy: -1.6,
                  text: isCrit ? `CRIT ${finalDmg}!` : `${finalDmg}`,
                  color: isCrit ? '#FBBF24' : '#F8FAFC',
                  scale: isCrit ? 1.28 : 0.95,
                  alpha: 1,
                });
              }

              for (let s = 0; s < 6; s++) {
                sim.particles.push({
                  x: b.x,
                  y: b.y,
                  vx: (Math.random() - 0.5) * 6,
                  vy: (Math.random() - 0.5) * 6,
                  radius: 2.8,
                  color: isCrit ? '#FBBF24' : '#F43F5E',
                  alpha: 1,
                  decay: 0.06,
                });
              }

              if (bot.hp <= 0) {
                bot.alive = false;
                // Drop tactical loot crate on death
                sim.loots.push({
                  id: now + Math.random(),
                  x: bot.x,
                  y: bot.y,
                  kind: Math.random() > 0.5 ? 'shield' : 'gloo',
                  active: true,
                });

                const killerName =
                  b.ownerId === 'player'
                    ? 'YOU'
                    : sim.bots.find((x) => x.id === b.ownerId)?.name || 'SURVIVOR';

                pushKillFeed(
                  killerName,
                  bot.name,
                  b.ownerId === 'player' ? curWeapon.name : bot.weapon.name,
                  isCrit,
                  b.ownerId === 'player'
                );

                if (b.ownerId === 'player') {
                  sim.stats.kills += 1;
                  if (isCrit) sim.stats.headshots += 1;
                  setKills(sim.stats.kills);
                  setHeadshots(sim.stats.headshots);
                  soundEngine.playElimination();

                  const kCount = sim.stats.kills;
                  const bannerLabel =
                    kCount === 1
                      ? 'FIRST BLOOD // প্রথম এলিমিনেশন'
                      : kCount === 2
                      ? 'DOUBLE ELIMINATION!'
                      : kCount === 3
                      ? 'TRIPLE STRIKE!'
                      : kCount >= 4
                      ? `APEX RAMPAGE (${kCount}X)!`
                      : null;
                  if (bannerLabel) {
                    setStreakBanner(bannerLabel);
                    setTimeout(() => setStreakBanner(null), 2200);
                  }
                }
              }

              sim.bullets.splice(i, 1);
              break;
            }
          }
        }

        // Expire old Gloo-Walls after 18s
        sim.glooWalls = sim.glooWalls.filter((g) => now - g.createdAt < 18000);

        // Victory Check!
        const remainingBots = sim.bots.filter((b) => b.alive).length;
        if (p.alive && remainingBots === 0) {
          sim.finished = true;
          soundEngine.playVictory();
          setMatchResult({ finished: true, won: true, placement: 1 });
        }

        // Throttled HUD Sync
        uiSyncAccumulator += dt;
        if (uiSyncAccumulator > 0.12) {
          uiSyncAccumulator = 0;
          setHp(Math.round(p.hp));
          setShield(Math.round(p.shield));
          setAliveCount(remainingBots + (p.alive ? 1 : 0));
          setDamageDealt(sim.stats.damage);
          setSkillCooldown(Math.max(0, Math.ceil((p.skillReadyAt - now) / 1000)));
          setSkillActiveLeft(Math.max(0, Number(((p.skillActiveUntil - now) / 1000).toFixed(1))));
          setZoneTimer(
            Math.max(
              0,
              Math.ceil((sim.zone.radius - sim.zone.minRadius) / Math.max(1, sim.zone.shrinkRate))
            )
          );
        }
      }

      // Update VFX Particles, Shockwaves & Floating Damage Numbers
      for (let i = sim.particles.length - 1; i >= 0; i--) {
        const pt = sim.particles[i];
        pt.x += pt.vx;
        pt.y += pt.vy;
        pt.alpha -= pt.decay;
        if (pt.alpha <= 0) sim.particles.splice(i, 1);
      }
      for (let i = sim.shockwaves.length - 1; i >= 0; i--) {
        const sw = sim.shockwaves[i];
        sw.r += (sw.maxR - sw.r) * 0.16;
        sw.alpha -= 0.032;
        if (sw.alpha <= 0) sim.shockwaves.splice(i, 1);
      }
      for (let i = sim.texts.length - 1; i >= 0; i--) {
        const tx = sim.texts[i];
        tx.y += tx.vy;
        tx.alpha -= 0.022;
        if (tx.alpha <= 0) sim.texts.splice(i, 1);
      }

      // ======================================================================
      // RENDER TACTICAL WORLD ON CANVAS
      // ======================================================================
      ctx.save();
      ctx.scale(dpr, dpr);

      // Deep Obsidian Tactical Floor
      ctx.fillStyle = '#070B12';
      ctx.fillRect(0, 0, vw, vh);

      const camX = p.x - vw / 2;
      const camY = p.y - vh / 2;
      ctx.translate(-camX, -camY);

      // Cybernetic Tactical Grid
      const gridStep = 90;
      const startGX = Math.floor(Math.max(0, camX) / gridStep) * gridStep;
      const endGX = Math.min(sim.worldSize, camX + vw + gridStep);
      const startGY = Math.floor(Math.max(0, camY) / gridStep) * gridStep;
      const endGY = Math.min(sim.worldSize, camY + vh + gridStep);

      ctx.strokeStyle = 'rgba(148, 163, 184, 0.055)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = startGX; x <= endGX; x += gridStep) {
        ctx.moveTo(x, Math.max(0, camY));
        ctx.lineTo(x, Math.min(sim.worldSize, camY + vh));
      }
      for (let y = startGY; y <= endGY; y += gridStep) {
        ctx.moveTo(Math.max(0, camX), y);
        ctx.lineTo(Math.min(sim.worldSize, camX + vw), y);
      }
      ctx.stroke();

      // World Arena Boundary
      ctx.strokeStyle = 'rgba(255, 158, 11, 0.35)';
      ctx.lineWidth = 3;
      ctx.strokeRect(0, 0, sim.worldSize, sim.worldSize);

      // Safe Zone Guidance Line if player near/outside border
      if (Math.hypot(p.x - sim.zone.x, p.y - sim.zone.y) > sim.zone.radius * 0.78) {
        ctx.save();
        ctx.setLineDash([8, 8]);
        ctx.strokeStyle = 'rgba(0, 229, 255, 0.35)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(sim.zone.x, sim.zone.y);
        ctx.stroke();
        ctx.restore();
      }

      // Loot Crates & Golden Orbital Airdrops
      for (const item of sim.loots) {
        if (!item.active) continue;
        if (
          item.x < camX - 60 ||
          item.x > camX + vw + 60 ||
          item.y < camY - 60 ||
          item.y > camY + vh + 60
        )
          continue;

        const pulse = 1 + Math.sin(now * 0.005 + item.id) * 0.12;
        const itemColor =
          item.kind === 'airdrop'
            ? '#FF9E0B'
            : item.kind === 'medkit'
            ? '#10B981'
            : item.kind === 'shield'
            ? '#38BDF8'
            : '#00E5FF';

        ctx.save();
        ctx.translate(item.x, item.y);
        // Subtle radial glow
        const grad = ctx.createRadialGradient(0, 0, 2, 0, 0, item.kind === 'airdrop' ? 36 : 22);
        grad.addColorStop(0, itemColor + '55');
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(0, 0, (item.kind === 'airdrop' ? 36 : 22) * pulse, 0, Math.PI * 2);
        ctx.fill();

        const sz = item.kind === 'airdrop' ? 15 : 10;
        ctx.fillStyle = '#0F172A';
        ctx.strokeStyle = itemColor;
        ctx.lineWidth = item.kind === 'airdrop' ? 2.4 : 1.6;
        ctx.beginPath();
        ctx.roundRect(-sz, -sz, sz * 2, sz * 2, 4);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = itemColor;
        ctx.font = '700 10px "JetBrains Mono"';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(
          item.kind === 'airdrop'
            ? 'EVO'
            : item.kind === 'medkit'
            ? '+'
            : item.kind === 'shield'
            ? 'S'
            : 'W',
          0,
          0.5
        );
        ctx.restore();
      }

      // Architectural Compounds & Obstacles
      for (const o of sim.obstacles) {
        if (
          o.x + o.w < camX - 40 ||
          o.x > camX + vw + 40 ||
          o.y + o.h < camY - 40 ||
          o.y > camY + vh + 40
        )
          continue;

        // Drop shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
        ctx.fillRect(o.x + 6, o.y + 8, o.w, o.h);

        // Structure roof
        ctx.fillStyle = o.color;
        ctx.strokeStyle =
          o.kind === 'building' ? 'rgba(0, 229, 255, 0.25)' : 'rgba(255, 158, 11, 0.25)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.roundRect(o.x, o.y, o.w, o.h, 6);
        ctx.fill();
        ctx.stroke();

        // Subtle roof tech detail line
        ctx.strokeStyle = 'rgba(255,255,255,0.06)';
        ctx.strokeRect(o.x + 8, o.y + 8, o.w - 16, o.h - 16);
      }

      // Curved Aether Gloo-Walls!
      for (const gw of sim.glooWalls) {
        ctx.save();
        ctx.translate(gw.x, gw.y);
        ctx.rotate(gw.angle);

        // Energy aura
        ctx.shadowColor = gw.color;
        ctx.shadowBlur = 16;
        ctx.strokeStyle = gw.color;
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(-18, 0, 52, -0.92, 0.92);
        ctx.stroke();

        // Inner crystalline core line
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(-18, 0, 52, -0.88, 0.88);
        ctx.stroke();
        ctx.restore();
      }

      // Bullets & Laser Rail Trails
      for (const b of sim.bullets) {
        ctx.save();
        ctx.strokeStyle = b.color;
        ctx.shadowColor = b.color;
        ctx.shadowBlur = 8;
        ctx.lineWidth = b.isSniper ? 3.4 : 2.2;
        ctx.beginPath();
        ctx.moveTo(b.x, b.y);
        ctx.lineTo(b.x - b.vx * (b.isSniper ? 1.9 : 1.1), b.y - b.vy * (b.isSniper ? 1.9 : 1.1));
        ctx.stroke();
        ctx.restore();
      }

      // AI Survivors
      const valkyrieScan = skillActive && operator.id === 'valkyrie';
      for (const bot of sim.bots) {
        if (!bot.alive) continue;
        if (
          !valkyrieScan &&
          (bot.x < camX - 80 || bot.x > camX + vw + 80 || bot.y < camY - 80 || bot.y > camY + vh + 80)
        )
          continue;

        ctx.save();
        ctx.translate(bot.x, bot.y);

        // Valkyrie Holo-Scan Reticle
        if (valkyrieScan) {
          ctx.strokeStyle = '#00E5FF';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(-26, -26, 52, 52);
        }

        // Bot Weapon & Body
        ctx.save();
        ctx.rotate(bot.angle);
        ctx.fillStyle = '#334155';
        ctx.fillRect(10, -3, 20, 6);
        ctx.beginPath();
        ctx.arc(0, 0, 17, 0, Math.PI * 2);
        ctx.fillStyle = '#1E293B';
        ctx.fill();
        ctx.lineWidth = 2.4;
        ctx.strokeStyle = bot.color;
        ctx.stroke();
        ctx.restore();

        // Bot Name & Mini HP Bar
        ctx.fillStyle = 'rgba(7, 10, 16, 0.78)';
        ctx.fillRect(-24, -32, 48, 5);
        ctx.fillStyle = '#F43F5E';
        ctx.fillRect(-24, -32, 48 * Math.max(0, bot.hp / bot.maxHp), 5);

        ctx.fillStyle = 'rgba(248, 250, 252, 0.78)';
        ctx.font = '600 10px "Rajdhani"';
        ctx.textAlign = 'center';
        ctx.fillText(bot.name, 0, -37);
        ctx.restore();
      }

      // Player Character
      if (p.alive) {
        ctx.save();
        ctx.translate(p.x, p.y);

        // Active Skill Aura
        if (skillActive) {
          ctx.beginPath();
          ctx.arc(0, 0, 32 + Math.sin(now * 0.015) * 3, 0, Math.PI * 2);
          ctx.strokeStyle = operator.accentColor;
          ctx.lineWidth = 2.5;
          ctx.stroke();
        }

        // Laser Aim Line (subtle tactical sightline)
        ctx.save();
        ctx.rotate(p.angle);
        const laserGrad = ctx.createLinearGradient(22, 0, 210, 0);
        laserGrad.addColorStop(0, curWeapon.accent + '66');
        laserGrad.addColorStop(1, 'transparent');
        ctx.strokeStyle = laserGrad;
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(22, 0);
        ctx.lineTo(210, 0);
        ctx.stroke();

        // Equipped Sci-Fi Gun Barrel
        ctx.fillStyle = '#0F172A';
        ctx.strokeStyle = curWeapon.accent;
        ctx.lineWidth = 1.6;
        ctx.fillRect(12, -4, 24, 8);
        ctx.strokeRect(12, -4, 24, 8);

        // Armored Shoulders & Helmet Core
        ctx.beginPath();
        ctx.arc(0, 0, 19, 0, Math.PI * 2);
        ctx.fillStyle = '#0F172A';
        ctx.fill();
        ctx.lineWidth = 2.8;
        ctx.strokeStyle = operator.accentColor;
        ctx.stroke();

        // Glowing Visor Slit
        ctx.fillStyle = operator.accentColor;
        ctx.fillRect(6, -5, 7, 10);
        ctx.restore();

        // Reload Progress Ring around player
        if (p.reloadingUntil > now) {
          const prog = 1 - (p.reloadingUntil - now) / curWeapon.reloadMs;
          ctx.beginPath();
          ctx.arc(0, 0, 27, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.max(0, prog));
          ctx.strokeStyle = '#FF9E0B';
          ctx.lineWidth = 2.5;
          ctx.stroke();
        }
        ctx.restore();
      }

      // Shockwaves & Particles
      for (const sw of sim.shockwaves) {
        ctx.save();
        ctx.globalAlpha = Math.max(0, sw.alpha);
        ctx.strokeStyle = sw.color;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(sw.x, sw.y, sw.r, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
      for (const pt of sim.particles) {
        ctx.save();
        ctx.globalAlpha = Math.max(0, pt.alpha);
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, pt.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Shrinking Aether Storm Ring & Exterior Danger Tint
      ctx.save();
      ctx.beginPath();
      ctx.rect(camX - 20, camY - 20, vw + 40, vh + 40);
      ctx.arc(sim.zone.x, sim.zone.y, sim.zone.radius, 0, Math.PI * 2, true);
      ctx.fillStyle = 'rgba(225, 29, 72, 0.16)';
      ctx.fill();

      ctx.beginPath();
      ctx.arc(sim.zone.x, sim.zone.y, sim.zone.radius, 0, Math.PI * 2);
      ctx.strokeStyle = '#00E5FF';
      ctx.lineWidth = 3.5;
      ctx.stroke();
      ctx.restore();

      // Floating Damage & Crit Headshot Numbers
      for (const tx of sim.texts) {
        ctx.save();
        ctx.globalAlpha = Math.max(0, tx.alpha);
        ctx.font = `700 ${Math.round(14 * tx.scale)}px "Rajdhani", sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillStyle = '#000000';
        ctx.fillText(tx.text, tx.x + 1, tx.y + 1);
        ctx.fillStyle = tx.color;
        ctx.fillText(tx.text, tx.x, tx.y);
        ctx.restore();
      }

      ctx.restore();

      // ======================================================================
      // RENDER TACTICAL RADAR MINIMAP
      // ======================================================================
      const mm = minimapRef.current;
      if (mm) {
        const mctx = mm.getContext('2d');
        if (mctx) {
          const mw = mm.width;
          const mh = mm.height;
          const scale = mw / sim.worldSize;
          mctx.clearRect(0, 0, mw, mh);
          mctx.fillStyle = 'rgba(7, 11, 18, 0.85)';
          mctx.fillRect(0, 0, mw, mh);

          // Obstacles on minimap
          mctx.fillStyle = 'rgba(148, 163, 184, 0.25)';
          for (const o of sim.obstacles) {
            mctx.fillRect(o.x * scale, o.y * scale, Math.max(2, o.w * scale), Math.max(2, o.h * scale));
          }

          // Golden Airdrops
          mctx.fillStyle = '#FF9E0B';
          for (const l of sim.loots) {
            if (l.active && l.kind === 'airdrop') {
              mctx.fillRect(l.x * scale - 2, l.y * scale - 2, 4, 4);
            }
          }

          // Safe Zone Ring
          mctx.strokeStyle = '#00E5FF';
          mctx.lineWidth = 1.5;
          mctx.beginPath();
          mctx.arc(sim.zone.x * scale, sim.zone.y * scale, sim.zone.radius * scale, 0, Math.PI * 2);
          mctx.stroke();

          // Scanned or nearby firing Bots
          for (const b of sim.bots) {
            if (!b.alive) continue;
            const recentlyFired = now - b.lastShot < 900;
            if (valkyrieScan || recentlyFired) {
              mctx.fillStyle = '#F43F5E';
              mctx.beginPath();
              mctx.arc(b.x * scale, b.y * scale, 2.5, 0, Math.PI * 2);
              mctx.fill();
            }
          }

          // Player Dot
          mctx.fillStyle = '#10B981';
          mctx.beginPath();
          mctx.arc(p.x * scale, p.y * scale, 3.5, 0, Math.PI * 2);
          mctx.fill();
        }
      }

      rafId = requestAnimationFrame(step);
    };

    rafId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafId);
  }, [operator, primaryWeapon, secondaryWeapon, triggerReload]);

  // Dual Virtual Joystick Touch Handlers for Mobile / APK Mode
  const handleLeftPadStart = (e: React.TouchEvent<HTMLDivElement>) => {
    const t = e.changedTouches[0];
    const rect = e.currentTarget.getBoundingClientRect();
    simRef.current.touchMove = {
      active: true,
      id: t.identifier,
      originX: rect.left + rect.width / 2,
      originY: rect.top + rect.height / 2,
      dx: 0,
      dy: 0,
    };
  };

  const handleLeftPadMove = (e: React.TouchEvent<HTMLDivElement>) => {
    const tm = simRef.current.touchMove;
    if (!tm.active) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier === tm.id) {
        const maxR = 46;
        const rx = t.clientX - tm.originX;
        const ry = t.clientY - tm.originY;
        const dist = Math.min(maxR, Math.hypot(rx, ry));
        const ang = Math.atan2(ry, rx);
        tm.dx = (Math.cos(ang) * dist) / maxR;
        tm.dy = (Math.sin(ang) * dist) / maxR;
      }
    }
  };

  const handleLeftPadEnd = () => {
    simRef.current.touchMove.active = false;
    simRef.current.touchMove.dx = 0;
    simRef.current.touchMove.dy = 0;
  };

  const handleFirePadStart = (e: React.TouchEvent<HTMLDivElement>) => {
    const t = e.changedTouches[0];
    const rect = e.currentTarget.getBoundingClientRect();
    simRef.current.touchAim = {
      active: true,
      firing: true,
      id: t.identifier,
      originX: rect.left + rect.width / 2,
      originY: rect.top + rect.height / 2,
      dx: 0,
      dy: 0,
    };
  };

  const handleFirePadMove = (e: React.TouchEvent<HTMLDivElement>) => {
    const ta = simRef.current.touchAim;
    if (!ta.active) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier === ta.id) {
        ta.dx = t.clientX - ta.originX;
        ta.dy = t.clientY - ta.originY;
      }
    }
  };

  const handleFirePadEnd = () => {
    simRef.current.touchAim.active = false;
    simRef.current.touchAim.firing = false;
  };

  const displayedWeapon = activeSlot === 0 ? primaryWeapon : secondaryWeapon;
  const rewardGold = matchResult
    ? (matchResult.won ? 450 : 140) + kills * 65 + Math.round(damageDealt * 0.15)
    : 0;
  const rewardGems = matchResult ? (matchResult.won ? 45 : 10) + kills * 5 : 0;

  return (
    <div className="fixed inset-0 z-50 bg-[#070B12] overflow-hidden select-none cursor-crosshair">
      <canvas ref={canvasRef} className="block w-full h-full" />

      {/* ====================================================================
          TOP-LEFT: SELECTIVE GLASS MINIMAP RADAR & ZONE TIMER
          ==================================================================== */}
      <div className="fixed top-3 left-3 sm:top-4 sm:left-4 flex items-start gap-3 pointer-events-none">
        <div className="glass-capsule rounded-xl p-1.5 relative">
          <canvas
            ref={minimapRef}
            width={136}
            height={136}
            className="rounded-lg block w-[112px] h-[112px] sm:w-[136px] sm:h-[136px]"
          />
          <div className="mt-1 px-1.5 flex items-center justify-between text-[11px] font-mono-tech text-slate-300">
            <span className="flex items-center gap-1 text-cyan-400">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
              ZONE
            </span>
            <span>{zoneTimer > 0 ? `${zoneTimer}s` : 'FINAL'}</span>
          </div>
        </div>

        {/* Operator Active Telemetry Pill */}
        <div className="hidden md:flex glass-subtle rounded-xl px-3.5 py-2 flex-col gap-0.5">
          <span className="text-[10px] tracking-widest uppercase text-amber-400 font-semibold">
            {operator.codename}
          </span>
          <span className="text-xs text-slate-300">
            {lang === 'bn' ? mode.nameBn : mode.nameEn}
          </span>
        </div>
      </div>

      {/* ====================================================================
          TOP-CENTER: KILL STREAK ANNOUNCER
          ==================================================================== */}
      {streakBanner && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 pointer-events-none z-30 animate-bounce">
          <div className="glass-capsule px-6 py-2 rounded-full border-amber-400/50 flex items-center gap-2.5 shadow-[0_0_30px_rgba(255,158,11,0.4)]">
            <Flame className="w-5 h-5 text-amber-400" />
            <span className="font-display font-bold tracking-wider text-base sm:text-lg text-amber-300">
              {streakBanner}
            </span>
          </div>
        </div>
      )}

      {/* ====================================================================
          TOP-RIGHT: ALIVE / KILLS TELEMETRY + LIVE KILL FEED + EXIT
          ==================================================================== */}
      <div className="fixed top-3 right-3 sm:top-4 sm:right-4 flex flex-col items-end gap-2.5 z-20">
        <div className="flex items-center gap-2">
          <div className="glass-capsule rounded-xl px-3.5 py-1.5 flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-slate-400 font-display uppercase">
                {lang === 'bn' ? 'জীবিত' : 'ALIVE'}
              </span>
              <span className="font-mono-tech font-bold text-base text-cyan-400">{aliveCount}</span>
            </div>
            <div className="w-px h-4 bg-white/10" />
            <div className="flex items-center gap-1.5">
              <Crosshair className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[11px] text-slate-400 font-display uppercase">
                {lang === 'bn' ? 'কিল' : 'KILLS'}
              </span>
              <span className="font-mono-tech font-bold text-base text-amber-400">{kills}</span>
            </div>
          </div>

          <button
            onClick={() => setShowTouchHud((v) => !v)}
            title="Toggle Mobile Touch Controls"
            className={`glass-subtle p-2 rounded-xl transition cursor-pointer ${
              showTouchHud ? 'text-cyan-400 border-cyan-400/40' : 'text-slate-300 hover:text-white'
            }`}
          >
            <Smartphone className="w-4 h-4" />
          </button>

          <button
            onClick={() => onExitMatch(kills * 50, kills * 4, kills, false)}
            title="Leave Match"
            className="glass-subtle p-2 rounded-xl text-slate-300 hover:text-rose-400 transition cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>

        {/* Live Kill Feed */}
        <div className="flex flex-col items-end gap-1 pointer-events-none">
          {killFeed.map((kf) => (
            <div
              key={kf.id}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-display tracking-wide flex items-center gap-1.5 border ${
                kf.isPlayer
                  ? 'bg-amber-500/20 border-amber-400/40 text-amber-200'
                  : 'bg-[#090D16]/80 border-white/10 text-slate-300'
              }`}
            >
              <span className="font-bold">{kf.killer}</span>
              <span className="text-[10px] px-1 rounded bg-white/10 text-cyan-300">
                {kf.isCrit ? 'HEADSHOT' : kf.weaponName.split('-')[0]}
              </span>
              <span className="text-rose-300">{kf.victim}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ====================================================================
          BOTTOM-CENTER: HEALTH / SHIELD + TACTICAL LOADOUT DECK
          ==================================================================== */}
      <div className="fixed bottom-3 left-1/2 -translate-x-1/2 w-[94%] max-w-xl flex flex-col gap-2 z-20 pointer-events-auto">
        {/* Tactical Ability & Consumables Row */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {/* Aether Gloo-Wall Button [Q] */}
            <button
              onClick={deployGlooWall}
              disabled={glooCount <= 0}
              className={`glass-capsule px-3 py-2 rounded-xl flex items-center gap-2 transition cursor-pointer ${
                glooCount > 0
                  ? 'hover:border-cyan-400/60 text-cyan-300'
                  : 'opacity-45 cursor-not-allowed text-slate-500'
              }`}
            >
              <Shield className="w-4 h-4 text-cyan-400" />
              <div className="text-left leading-tight">
                <div className="text-[10px] text-slate-400 font-mono-tech">[Q] WALL</div>
                <div className="text-xs font-bold font-mono-tech">{glooCount}x</div>
              </div>
            </button>

            {/* Operator Skill Button [E] */}
            <button
              onClick={triggerOperatorSkill}
              disabled={skillCooldown > 0}
              className={`glass-capsule px-3 py-2 rounded-xl flex items-center gap-2 transition cursor-pointer ${
                skillActiveLeft > 0
                  ? 'border-amber-400 bg-amber-500/25 text-amber-200'
                  : skillCooldown === 0
                  ? 'hover:border-amber-400/60 text-amber-300'
                  : 'opacity-55 text-slate-400'
              }`}
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <div className="text-left leading-tight">
                <div className="text-[10px] text-slate-400 font-mono-tech">[E] SKILL</div>
                <div className="text-xs font-bold font-mono-tech">
                  {skillActiveLeft > 0
                    ? `${skillActiveLeft}s`
                    : skillCooldown > 0
                    ? `${skillCooldown}s`
                    : 'READY'}
                </div>
              </div>
            </button>

            {/* Medkit Button [H] */}
            <button
              onClick={useMedkit}
              disabled={medkitCount <= 0 || hp >= 100}
              className={`glass-capsule px-3 py-2 rounded-xl flex items-center gap-2 transition cursor-pointer ${
                medkitCount > 0 && hp < 100
                  ? 'hover:border-emerald-400/60 text-emerald-300'
                  : 'opacity-50 text-slate-400'
              }`}
            >
              <HeartPulse className="w-4 h-4 text-emerald-400" />
              <div className="text-left leading-tight">
                <div className="text-[10px] text-slate-400 font-mono-tech">[H] HEAL</div>
                <div className="text-xs font-bold font-mono-tech">{medkitCount}x</div>
              </div>
            </button>
          </div>

          {/* Weapon Slot Switcher & Ammo */}
          <div className="obsidian-card rounded-xl px-3 py-1.5 flex items-center gap-3 border border-white/12">
            <button
              onClick={() => swapWeapon()}
              className="flex items-center gap-2 cursor-pointer group"
              title="Swap Weapon [1 / 2]"
            >
              <WeaponArtwork
                weaponId={displayedWeapon.id}
                accent={displayedWeapon.accent}
                className="w-16 h-7"
              />
              <div className="text-left hidden sm:block">
                <div className="text-[10px] text-slate-400 font-mono-tech">
                  [{activeSlot + 1}] {displayedWeapon.name.split('-')[0]}
                </div>
                <div className="text-sm font-mono-tech font-bold text-white">
                  {isReloading ? (
                    <span className="text-amber-400 text-xs">RELOADING...</span>
                  ) : (
                    <>
                      {ammo} <span className="text-slate-500 text-xs">/ ∞</span>
                    </>
                  )}
                </div>
              </div>
            </button>
            <button
              onClick={triggerReload}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 cursor-pointer"
              title="Reload [R]"
            >
              <RotateCw className={`w-3.5 h-3.5 ${isReloading ? 'animate-spin text-amber-400' : ''}`} />
            </button>
          </div>
        </div>

        {/* Crisp Shield + HP Dual Bar */}
        <div className="glass-capsule rounded-xl p-2.5 flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono-tech">
            <span className="text-cyan-300">SHIELD {shield}</span>
            <span className="text-emerald-300">HP {hp} / 100</span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-900/90 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 to-sky-400 transition-all duration-150"
              style={{ width: `${Math.min(100, (shield / maxShield) * 100)}%` }}
            />
          </div>
          <div className="w-full h-2.5 rounded-full bg-slate-900/90 overflow-hidden">
            <div
              className={`h-full transition-all duration-150 ${
                hp > 35
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                  : 'bg-gradient-to-r from-rose-600 to-amber-500'
              }`}
              style={{ width: `${Math.min(100, hp)}%` }}
            />
          </div>
        </div>
      </div>

      {/* ====================================================================
          MOBILE / APK DUAL VIRTUAL JOYSTICK OVERLAY
          ==================================================================== */}
      {showTouchHud && !matchResult && (
        <>
          {/* Left Movement Thumbstick */}
          <div
            onTouchStart={handleLeftPadStart}
            onTouchMove={handleLeftPadMove}
            onTouchEnd={handleLeftPadEnd}
            className="fixed bottom-28 left-5 w-28 h-28 rounded-full glass-subtle border-white/15 flex items-center justify-center z-20 touch-none"
          >
            <div className="w-11 h-11 rounded-full bg-white/15 border border-white/30 flex items-center justify-center text-[10px] font-mono-tech text-slate-300">
              MOVE
            </div>
          </div>

          {/* Right Aim & Auto-Fire Trigger Pad */}
          <div
            onTouchStart={handleFirePadStart}
            onTouchMove={handleFirePadMove}
            onTouchEnd={handleFirePadEnd}
            className="fixed bottom-28 right-5 w-28 h-28 rounded-full glass-capsule border-amber-400/45 flex items-center justify-center z-20 touch-none shadow-[0_0_25px_rgba(255,158,11,0.25)]"
          >
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 flex flex-col items-center justify-center text-slate-950 font-display font-bold text-xs">
              <Crosshair className="w-5 h-5" />
              FIRE
            </div>
          </div>
        </>
      )}

      {/* ====================================================================
          POST-MATCH VICTORY / SUMMARY SELECTIVE GLASS MODAL
          ==================================================================== */}
      {matchResult && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-modal-shell max-w-lg w-full rounded-2xl p-6 sm:p-8 text-center relative overflow-hidden">
            <div
              className={`mx-auto w-16 h-16 rounded-2xl flex items-center justify-center mb-4 ${
                matchResult.won
                  ? 'bg-gradient-to-br from-amber-400 to-orange-600 text-slate-950 shadow-[0_0_40px_rgba(255,158,11,0.5)]'
                  : 'bg-rose-500/20 border border-rose-500/40 text-rose-400'
              }`}
            >
              {matchResult.won ? <Trophy className="w-9 h-9" /> : <Skull className="w-9 h-9" />}
            </div>

            <div className="text-xs font-mono-tech tracking-[0.25em] uppercase text-amber-400 mb-1">
              {matchResult.won ? 'APEX ECLIPSE // CHAMPION' : `RANK #${matchResult.placement}`}
            </div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-wide text-white mb-2">
              {matchResult.won
                ? lang === 'bn'
                  ? 'সোলার ভিক্টরি অর্জন করেছেন!'
                  : 'ECLIPSE VICTORY!'
                : lang === 'bn'
                ? 'যুদ্ধে পরাজিত — আবার চেষ্টা করুন'
                : 'ELIMINATED IN ACTION'}
            </h2>
            <p className="text-slate-400 text-sm mb-6">
              {operator.codename} • {displayedWeapon.name}
            </p>

            {/* Combat Telemetry Grid */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="obsidian-card rounded-xl p-3">
                <div className="text-[11px] text-slate-400 uppercase">
                  {lang === 'bn' ? 'এলিমিনেশন' : 'ELIMINATIONS'}
                </div>
                <div className="font-mono-tech text-2xl font-bold text-amber-400 mt-0.5">{kills}</div>
              </div>
              <div className="obsidian-card rounded-xl p-3">
                <div className="text-[11px] text-slate-400 uppercase">
                  {lang === 'bn' ? 'মোট ড্যামেজ' : 'DAMAGE'}
                </div>
                <div className="font-mono-tech text-2xl font-bold text-cyan-400 mt-0.5">
                  {damageDealt}
                </div>
              </div>
              <div className="obsidian-card rounded-xl p-3">
                <div className="text-[11px] text-slate-400 uppercase">
                  {lang === 'bn' ? 'ক্রিট হেডশট' : 'HEADSHOTS'}
                </div>
                <div className="font-mono-tech text-2xl font-bold text-emerald-400 mt-0.5">
                  {headshots}
                </div>
              </div>
            </div>

            {/* Rewards Strip */}
            <div className="obsidian-card rounded-xl p-3.5 mb-6 flex items-center justify-around border border-amber-500/25">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-400" />
                <span className="text-sm font-semibold text-amber-300">
                  +{matchResult.won ? 52 : Math.max(8, kills * 9)} RANK RP
                </span>
              </div>
              <div className="text-sm font-mono-tech text-yellow-300">+{rewardGold} GOLD</div>
              <div className="text-sm font-mono-tech text-cyan-300">+{rewardGems} GEMS</div>
            </div>

            <button
              onClick={() => onExitMatch(rewardGold, rewardGems, kills, matchResult.won)}
              className="w-full py-3.5 chamfer-btn bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-display font-bold text-lg tracking-wider uppercase cursor-pointer transition shadow-[0_10px_30px_rgba(255,120,0,0.35)]"
            >
              {lang === 'bn' ? 'পুরস্কার নিন ও লবিতে ফিরুন' : 'CLAIM REWARDS & RETURN TO LOBBY'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
