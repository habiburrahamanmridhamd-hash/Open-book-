import React from 'react';
import { WeaponSpec } from '../data/gameData';

interface WeaponArtworkProps {
  weaponId: WeaponSpec['id'];
  accent: string;
  className?: string;
}

export const WeaponArtwork: React.FC<WeaponArtworkProps> = ({
  weaponId,
  accent,
  className = 'w-full h-24',
}) => {
  if (weaponId === 'solar_ar') {
    return (
      <svg viewBox="0 0 320 100" fill="none" className={className}>
        <defs>
          <linearGradient id="arBody" x1="0" y1="0" x2="320" y2="100" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#2A3447" />
            <stop offset="55%" stopColor="#141B29" />
            <stop offset="100%" stopColor="#0B0F18" />
          </linearGradient>
        </defs>
        {/* Suppressor & Barrel */}
        <rect x="242" y="38" width="58" height="8" rx="2" fill="#1E293B" stroke={accent} strokeWidth="1" />
        <rect x="292" y="36" width="18" height="12" rx="2" fill="#0F172A" stroke={accent} strokeWidth="1.2" />
        {/* Receiver & Handguard */}
        <path
          d="M58 32 L242 32 L250 42 L238 54 L154 54 L144 62 L84 62 L70 50 L58 50 Z"
          fill="url(#arBody)"
          stroke="rgba(255,255,255,0.22)"
          strokeWidth="1.3"
        />
        {/* Tactical Stock */}
        <path
          d="M14 34 L58 33 L58 52 L34 62 L14 62 Z"
          fill="#111827"
          stroke="rgba(255,255,255,0.18)"
          strokeWidth="1.2"
        />
        {/* Holo Sight */}
        <path d="M122 20 L162 20 L168 32 L118 32 Z" fill="#0F172A" stroke={accent} strokeWidth="1.3" />
        <line x1="132" y1="25" x2="154" y2="25" stroke={accent} strokeWidth="2" />
        {/* Angled Mag with Glowing Core */}
        <path d="M146 54 L166 54 L180 90 L158 92 Z" fill="#131B2B" stroke="rgba(255,255,255,0.2)" />
        <line x1="158" y1="60" x2="169" y2="85" stroke={accent} strokeWidth="2.5" strokeLinecap="round" />
        {/* Pistol Grip */}
        <path d="M98 60 L114 60 L106 86 L90 86 Z" fill="#0F172A" stroke="rgba(255,255,255,0.16)" />
        {/* Glowing Evo Core Strip */}
        <line x1="88" y1="42" x2="232" y2="42" stroke={accent} strokeWidth="2.6" strokeLinecap="round" />
        <circle cx="136" cy="42" r="3.5" fill={accent} />
      </svg>
    );
  }

  if (weaponId === 'vortex_smg') {
    return (
      <svg viewBox="0 0 320 100" fill="none" className={className}>
        {/* Compact Vector-style Sci-Fi SMG */}
        <rect x="220" y="38" width="46" height="9" rx="3" fill="#1E293B" stroke={accent} strokeWidth="1.2" />
        <path
          d="M68 30 L224 30 L232 45 L212 64 L148 64 L138 54 L72 54 Z"
          fill="#151E30"
          stroke="rgba(255,255,255,0.22)"
          strokeWidth="1.3"
        />
        {/* Folding Skeleton Stock */}
        <path d="M24 35 L68 35 L68 44 L34 54 L24 54 Z" fill="#0F172A" stroke="rgba(255,255,255,0.18)" />
        {/* Reflex Optic */}
        <rect x="128" y="19" width="34" height="11" rx="2" fill="#0B1220" stroke={accent} strokeWidth="1.3" />
        {/* Extended Cyber Mag */}
        <path d="M166 62 L184 62 L198 94 L180 95 Z" fill="#0F172A" stroke={accent} strokeWidth="1.1" />
        {/* Grip */}
        <path d="M108 54 L124 54 L118 84 L102 84 Z" fill="#0F172A" stroke="rgba(255,255,255,0.16)" />
        {/* Cyan Plasma Vents */}
        <line x1="94" y1="41" x2="208" y2="41" stroke={accent} strokeWidth="3" strokeDasharray="14 6" />
      </svg>
    );
  }

  if (weaponId === 'valkyrie_sr') {
    return (
      <svg viewBox="0 0 320 100" fill="none" className={className}>
        {/* Long Dual-Rail Sniper Barrel */}
        <line x1="196" y1="37" x2="310" y2="37" stroke={accent} strokeWidth="3" />
        <line x1="196" y1="45" x2="306" y2="45" stroke="#475569" strokeWidth="3.5" />
        <path
          d="M48 33 L204 33 L214 48 L184 56 L78 56 L62 49 L48 49 Z"
          fill="#131C2E"
          stroke="rgba(255,255,255,0.24)"
          strokeWidth="1.3"
        />
        {/* Precision Cheek-Rest Stock */}
        <path d="M8 35 L48 35 L48 52 L16 62 L8 58 Z" fill="#0F172A" stroke="rgba(255,255,255,0.2)" />
        {/* Long-Range Ballistic Scope */}
        <path d="M102 15 L182 15 L176 27 L108 27 Z" fill="#0B1324" stroke={accent} strokeWidth="1.3" />
        <line x1="122" y1="27" x2="122" y2="33" stroke="#64748B" strokeWidth="3" />
        <line x1="162" y1="27" x2="162" y2="33" stroke="#64748B" strokeWidth="3" />
        {/* Mag & Grip */}
        <rect x="134" y="56" width="24" height="22" rx="2" fill="#0F172A" stroke={accent} strokeWidth="1" />
        <path d="M90 56 L105 56 L98 84 L83 84 Z" fill="#0F172A" stroke="rgba(255,255,255,0.16)" />
        <circle cx="152" cy="43" r="4" fill={accent} />
      </svg>
    );
  }

  // Plasma Shotgun
  return (
    <svg viewBox="0 0 320 100" fill="none" className={className}>
      {/* Heavy Twin-Core Barrel */}
      <rect x="198" y="32" width="88" height="10" rx="2" fill="#1E293B" stroke={accent} strokeWidth="1.2" />
      <rect x="198" y="44" width="80" height="9" rx="2" fill="#0F172A" stroke="rgba(255,255,255,0.2)" />
      {/* Armored Receiver */}
      <path
        d="M62 30 L204 30 L204 58 L98 60 L74 52 L62 52 Z"
        fill="#181F30"
        stroke="rgba(255,255,255,0.24)"
        strokeWidth="1.4"
      />
      {/* Heavy Breacher Stock */}
      <path d="M14 36 L62 33 L62 54 L22 68 L14 62 Z" fill="#0F172A" stroke="rgba(255,255,255,0.18)" />
      {/* Glowing Plasma Cells */}
      <rect x="108" y="39" width="16" height="8" rx="2" fill={accent} />
      <rect x="130" y="39" width="16" height="8" rx="2" fill={accent} />
      <rect x="152" y="39" width="16" height="8" rx="2" fill={accent} />
      {/* Grip */}
      <path d="M84 56 L100 56 L92 84 L76 84 Z" fill="#0F172A" stroke="rgba(255,255,255,0.16)" />
    </svg>
  );
};
