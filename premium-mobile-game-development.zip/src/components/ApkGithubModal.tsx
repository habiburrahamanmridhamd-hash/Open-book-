import React, { useState } from 'react';
import JSZip from 'jszip';
import {
  X,
  Download,
  GitBranch,
  Smartphone,
  CheckCircle2,
  Copy,
  Check,
  Terminal,
  Cpu,
  ShieldCheck,
  Sparkles,
  Maximize2,
  Layers,
} from 'lucide-react';
import { Language } from '../data/gameData';
import { soundEngine } from '../utils/soundEngine';

interface ApkGithubModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const ApkGithubModal: React.FC<ApkGithubModalProps> = ({ isOpen, onClose, lang }) => {
  const [appName, setAppName] = useState('Apex Eclipse');
  const [packageId, setPackageId] = useState('com.apexeclipse.battlegrounds');
  const [versionTag, setVersionTag] = useState('v1.0.0');
  const [repoName, setRepoName] = useState('my-studio/apex-eclipse-apk');
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildStep, setBuildStep] = useState(0);
  const [buildDone, setBuildDone] = useState(false);
  const [copiedTab, setCopiedTab] = useState<string | null>(null);
  const [activeCodeTab, setActiveCodeTab] = useState<'workflow' | 'capacitor' | 'guide'>('workflow');

  if (!isOpen) return null;

  const cleanApkFileName = `${appName.replace(/[^a-zA-Z0-9]/g, '')}-${versionTag}.apk`;

  const githubWorkflowYaml = `name: Build Android APK & Publish GitHub Release

on:
  push:
    branches: [ "main", "master" ]
    tags: [ "v*" ]
  workflow_dispatch:

permissions:
  contents: write

jobs:
  build-android-apk:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Source Code
        uses: actions/checkout@v4

      - name: Setup Node.js 20
        uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Setup Java JDK 21 for Android Gradle
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '21'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Dependencies & Build Web Game
        run: |
          npm install
          npm run build

      - name: Initialize Capacitor Android Wrapper
        run: |
          npm install @capacitor/core @capacitor/cli @capacitor/android
          if [ ! -d "android" ]; then
            npx cap init "${appName}" "${packageId}" --web-dir dist
            npx cap add android
          fi
          npx cap sync android

      - name: Configure Landscape Immersive Game Mode
        run: |
          sed -i 's/android:name=".MainActivity"/android:name=".MainActivity" android:screenOrientation="sensorLandscape"/' android/app/src/main/AndroidManifest.xml || true

      - name: Compile Android APK with Gradle
        working-directory: android
        run: |
          chmod +x gradlew
          ./gradlew assembleDebug

      - name: Rename Output APK
        run: |
          cp android/app/build/outputs/apk/debug/app-debug.apk ./${cleanApkFileName}

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: ${cleanApkFileName}
          path: ./${cleanApkFileName}

      - name: Auto-Publish APK to GitHub Releases
        uses: softprops/action-gh-release@v2
        with:
          tag_name: ${versionTag}
          name: "${appName} ${versionTag} (Android APK)"
          body: |
            ## 🔥 ${appName} — Official Android APK Release (${versionTag})
            - **Package ID:** \`${packageId}\`
            - **Engine:** 60FPS Selective-Glass Tactical Battle Royale
            - **Controls:** Dual Virtual Touch Joysticks + Glass Skill HUD
            - নিচের **Assets** সেকশন থেকে সরাসরি \`${cleanApkFileName}\` ডাউনলোড করে Android ফোনে ইনস্টল করুন!
          files: ./${cleanApkFileName}
        env:
          GITHUB_TOKEN: \${{ secrets.GITHUB_TOKEN }}
`;

  const capacitorConfigJson = JSON.stringify(
    {
      appId: packageId,
      appName: appName,
      webDir: 'dist',
      bundledWebRuntime: false,
      server: {
        androidScheme: 'https',
      },
      android: {
        allowMixedContent: true,
        backgroundColor: '#070A10',
      },
    },
    null,
    2
  );

  const guideMarkdown = `# 🚀 ${appName} — GitHub থেকে ফ্রি APK বিল্ড ও পাবলিশ গাইড

আপনার পিসিতে Android Studio ইনস্টল না থাকলেও **GitHub Actions** ক্লাউড সার্ভার ব্যবহার করে সম্পূর্ণ ফ্রিতে আসল **Android \`.apk\`** তৈরি এবং **GitHub Releases**-এ পাবলিশ করতে পারবেন!

## ধাপ ১: GitHub Repository তৈরি করুন
1. [github.com/new](https://github.com/new)-এ গিয়ে একটি নতুন Public Repository খুলুন (যেমন: \`${repoName.split('/')[1] || 'apex-eclipse-apk'}\`)।

## ধাপ ২: প্রজেক্ট ও এই APK Kit ফাইলগুলো আপলোড করুন
1. আপনার গেম প্রজেক্টের ফোল্ডারে এই জিপ ফাইলের ভেতরে থাকা ফাইলগুলো (\`.github/workflows/build-apk.yml\` এবং \`capacitor.config.json\`) রাখুন।
2. টার্মিনালে নিচের কমান্ডগুলো চালান:
\`\`\`bash
git init
git add .
git commit -m "Initial release: ${appName} ${versionTag}"
git branch -M main
git remote add origin https://github.com/${repoName}.git
git push -u origin main
\`\`\`

## ধাপ ৩: অটোমেটিক APK ডাউনলোড ও রিলিজ লিংক শেয়ার!
1. কোড পুশ করার সাথে সাথে আপনার GitHub রেপোর **Actions** ট্যাবে যান।
2. মাত্র ২-৩ মিনিটের মধ্যে **Build Android APK & Publish GitHub Release** সবুজ টিক (✅) দেখাবে।
3. এবার আপনার রেপোর ডানপাশে **Releases** সেকশনে গেলেই **\`${cleanApkFileName}\`** ডাউনলোড লিংক পেয়ে যাবেন—যেকোনো মানুষ এক ক্লিকে ডাউনলোড করে ফোনে খেলতে পারবে!
`;

  const buildSteps = [
    lang === 'bn'
      ? 'WebGL / 60FPS ক্যানভাস ইঞ্জিন ও গ্লাস শেডার যাচাই হচ্ছে...'
      : 'Verifying 60FPS Tactical Canvas & Selective Glass Assets...',
    lang === 'bn'
      ? `Capacitor 6 Android কনফিগারেশন (${packageId}) তৈরি হচ্ছে...`
      : `Generating Capacitor 6 Android Manifest (${packageId})...`,
    lang === 'bn'
      ? 'GitHub Actions অটোমেটেড APK রিলিজ ওয়ার্কফ্লো যুক্ত হচ্ছে...'
      : 'Injecting GitHub Actions Automated Gradle APK Pipeline...',
    lang === 'bn'
      ? 'প্যাকেজিং সম্পন্ন! গিটহাব রিলিজ কিট ডাউনলোড হচ্ছে...'
      : 'Packaging complete! Downloading Ready-to-Publish GitHub APK Kit...',
  ];

  const handleDownloadApkKit = async () => {
    soundEngine.playUiSelect();
    setIsBuilding(true);
    setBuildDone(false);
    setBuildStep(0);

    for (let i = 0; i < buildSteps.length; i++) {
      setBuildStep(i);
      await new Promise((r) => setTimeout(r, 480));
    }

    const zip = new JSZip();
    zip.file('.github/workflows/build-apk.yml', githubWorkflowYaml);
    zip.file('capacitor.config.json', capacitorConfigJson);
    zip.file('GITHUB_APK_PUBLISH_GUIDE.md', guideMarkdown);
    zip.file(
      'build-local-apk.sh',
      `#!/usr/bin/env bash\nset -e\necho "Building ${appName} Web Bundle..."\nnpm install\nnpm run build\nnpm install @capacitor/core @capacitor/cli @capacitor/android\nnpx cap add android || true\nnpx cap sync android\ncd android && ./gradlew assembleDebug\necho "APK Ready at android/app/build/outputs/apk/debug/app-debug.apk"\n`
    );

    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${appName.toLowerCase().replace(/\s+/g, '-')}-github-apk-kit.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setIsBuilding(false);
    setBuildDone(true);
    soundEngine.playVictory();
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTab(key);
    soundEngine.playUiTick();
    setTimeout(() => setCopiedTab(null), 1800);
  };

  const enterFullscreenMobile = () => {
    soundEngine.playUiSelect();
    if (document.documentElement.requestFullscreen) {
      document.documentElement.requestFullscreen().catch(() => {});
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="glass-modal-shell w-full max-w-4xl rounded-2xl overflow-hidden my-auto border border-white/15">
        {/* Top Glass Header */}
        <div className="px-5 sm:px-7 py-4 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-amber-500/10 via-transparent to-cyan-500/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-slate-950 shadow-[0_0_20px_rgba(255,158,11,0.4)]">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-xl sm:text-2xl font-bold tracking-wide text-white">
                  {lang === 'bn'
                    ? 'ANDROID APK ও GITHUB RELEASES স্টুডিও'
                    : 'ANDROID APK & GITHUB RELEASE STUDIO'}
                </h2>
                <span className="px-2 py-0.5 text-[10px] font-mono-tech rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  CI/CD AUTO-APK
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {lang === 'bn'
                  ? 'Android Studio ছাড়াই সরাসরি GitHub Actions দিয়ে আসল .apk বিল্ড ও Releases-এ পাবলিশ করুন'
                  : 'Compile native Android .apk automatically in GitHub Cloud & publish to GitHub Releases'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 sm:p-7 grid grid-cols-1 lg:grid-cols-12 gap-6 max-h-[80vh] overflow-y-auto">
          {/* Left Column: APK Package Configurator */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="obsidian-card rounded-xl p-4 flex flex-col gap-3.5">
              <div className="flex items-center gap-2 text-xs font-mono-tech uppercase tracking-wider text-amber-400">
                <Cpu className="w-4 h-4" />
                {lang === 'bn' ? 'APK মেটাডেটা কনফিগারেশন' : 'APK MANIFEST CONFIGURATION'}
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">
                  {lang === 'bn' ? 'গেমের নাম (App Name)' : 'Game Title (App Name)'}
                </label>
                <input
                  type="text"
                  value={appName}
                  onChange={(e) => setAppName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#070A10] border border-white/12 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">
                  {lang === 'bn' ? 'প্যাকেজ আইডি (Android Package ID)' : 'Android Package ID'}
                </label>
                <input
                  type="text"
                  value={packageId}
                  onChange={(e) => setPackageId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#070A10] border border-white/12 text-xs font-mono-tech text-cyan-300 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">
                    {lang === 'bn' ? 'রিলিজ ভার্সন' : 'Release Tag'}
                  </label>
                  <input
                    type="text"
                    value={versionTag}
                    onChange={(e) => setVersionTag(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-[#070A10] border border-white/12 text-xs font-mono-tech text-amber-300 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Target ABI</label>
                  <div className="px-3 py-2 rounded-lg bg-[#070A10] border border-white/8 text-xs font-mono-tech text-emerald-400">
                    Universal APK
                  </div>
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">
                  {lang === 'bn' ? 'আপনার GitHub Repo নাম' : 'GitHub Repository Slug'}
                </label>
                <input
                  type="text"
                  value={repoName}
                  onChange={(e) => setRepoName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#070A10] border border-white/12 text-xs font-mono-tech text-slate-200 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {/* Output APK Summary Badge */}
            <div className="glass-subtle rounded-xl p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <div className="text-[11px] text-slate-400">
                    {lang === 'bn' ? 'আউটপুট APK ফাইল' : 'Output Release File'}
                  </div>
                  <div className="text-xs font-mono-tech font-bold text-white">
                    {cleanApkFileName}
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded bg-cyan-500/15 text-cyan-300">
                120Hz Landscape
              </span>
            </div>

            {/* Primary Download Kit CTA */}
            <button
              onClick={handleDownloadApkKit}
              disabled={isBuilding}
              className="relative overflow-hidden w-full py-3.5 px-4 chamfer-btn bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-display font-bold text-base tracking-wide flex items-center justify-center gap-2 cursor-pointer transition shadow-[0_10px_28px_rgba(255,120,0,0.35)]"
            >
              <Download className="w-5 h-5" />
              {isBuilding
                ? lang === 'bn'
                  ? 'APK কিট প্রস্তুত হচ্ছে...'
                  : 'GENERATING APK KIT...'
                : lang === 'bn'
                ? 'GitHub Auto-APK Kit ডাউনলোড (.zip)'
                : 'DOWNLOAD GITHUB AUTO-APK KIT (.ZIP)'}
            </button>

            {/* Instant Fullscreen Mobile App Launch */}
            <button
              onClick={enterFullscreenMobile}
              className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/12 text-xs font-semibold text-cyan-300 flex items-center justify-center gap-2 cursor-pointer transition"
            >
              <Maximize2 className="w-4 h-4" />
              {lang === 'bn'
                ? 'এখনই ফুলস্ক্রিন মোবাইল অ্যাপ মোডে চালু করুন'
                : 'Launch Fullscreen Mobile App Mode Now'}
            </button>

            {/* Build Progress Status */}
            {(isBuilding || buildDone) && (
              <div className="obsidian-card rounded-xl p-3.5 border border-emerald-500/30">
                {isBuilding ? (
                  <div className="flex items-center gap-2.5 text-xs text-amber-300">
                    <Sparkles className="w-4 h-4 animate-spin shrink-0" />
                    <span>{buildSteps[buildStep]}</span>
                  </div>
                ) : (
                  <div className="flex items-start gap-2.5 text-xs text-emerald-300">
                    <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                    <span>
                      {lang === 'bn'
                        ? `সফলভাবে ডাউনলোড হয়েছে! জিপ ফাইলটি আনজিপ করে আপনার GitHub রেপোতে পুশ করলেই স্বয়ংক্রিয়ভাবে ${cleanApkFileName} রিলিজ তৈরি হয়ে যাবে!`
                        : `Kit downloaded! Extract into your repo and push to GitHub to auto-build & publish ${cleanApkFileName} on GitHub Releases!`}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right Column: Live Workflow Code & Bengali 3-Step GitHub Guide */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            {/* 3-Step Visual GitHub Release Pipeline */}
            <div className="grid grid-cols-3 gap-2.5">
              <div className="obsidian-card rounded-xl p-3 border-t-2 border-t-amber-400">
                <div className="text-[10px] font-mono-tech text-amber-400 mb-0.5">STEP 01</div>
                <div className="text-xs font-bold text-white">
                  {lang === 'bn' ? 'কিট ডাউনলোড' : 'Download Kit'}
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  {lang === 'bn'
                    ? 'প্রজেক্টে .github/workflows ফোল্ডারটি যুক্ত করুন'
                    : 'Add the generated workflow & Capacitor config'}
                </p>
              </div>
              <div className="obsidian-card rounded-xl p-3 border-t-2 border-t-cyan-400">
                <div className="text-[10px] font-mono-tech text-cyan-400 mb-0.5">STEP 02</div>
                <div className="text-xs font-bold text-white">
                  {lang === 'bn' ? 'GitHub-এ পুশ' : 'Push to GitHub'}
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  {lang === 'bn'
                    ? 'GitHub ক্লাউড একাই Gradle দিয়ে APK কম্পাইল করবে'
                    : 'GitHub Actions compiles the Android .apk free'}
                </p>
              </div>
              <div className="obsidian-card rounded-xl p-3 border-t-2 border-t-emerald-400">
                <div className="text-[10px] font-mono-tech text-emerald-400 mb-0.5">STEP 03</div>
                <div className="text-xs font-bold text-white">
                  {lang === 'bn' ? 'Releases থেকে APK নিন' : 'GitHub Releases'}
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  {lang === 'bn'
                    ? 'Releases পেজে সরাসরি ডাউনলোডযোগ্য .apk পাবলিশ হবে!'
                    : 'Public .apk appears automatically under Releases!'}
                </p>
              </div>
            </div>

            {/* Code Inspector Tabs */}
            <div className="obsidian-card rounded-xl overflow-hidden flex-1 flex flex-col border border-white/10">
              <div className="px-3.5 py-2.5 bg-[#070A10] border-b border-white/10 flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setActiveCodeTab('workflow')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-mono-tech flex items-center gap-1.5 cursor-pointer transition ${
                      activeCodeTab === 'workflow'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <GitBranch className="w-3.5 h-3.5" />
                    build-apk.yml
                  </button>
                  <button
                    onClick={() => setActiveCodeTab('capacitor')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-mono-tech flex items-center gap-1.5 cursor-pointer transition ${
                      activeCodeTab === 'capacitor'
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5" />
                    capacitor.config.json
                  </button>
                  <button
                    onClick={() => setActiveCodeTab('guide')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-mono-tech flex items-center gap-1.5 cursor-pointer transition ${
                      activeCodeTab === 'guide'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Terminal className="w-3.5 h-3.5" />
                    বাংলা গাইড.md
                  </button>
                </div>

                <button
                  onClick={() =>
                    handleCopy(
                      activeCodeTab === 'workflow'
                        ? githubWorkflowYaml
                        : activeCodeTab === 'capacitor'
                        ? capacitorConfigJson
                        : guideMarkdown,
                      activeCodeTab
                    )
                  }
                  className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-slate-300 flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedTab === activeCodeTab ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-300">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>

              <pre className="p-4 text-[11px] leading-relaxed font-mono-tech text-slate-300 overflow-auto max-h-[290px] bg-[#06090F]">
                <code>
                  {activeCodeTab === 'workflow'
                    ? githubWorkflowYaml
                    : activeCodeTab === 'capacitor'
                    ? capacitorConfigJson
                    : guideMarkdown}
                </code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
