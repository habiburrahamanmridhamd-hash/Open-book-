import heroPhantomImg from '../assets/images/hero-phantom.jpg';
import heroValkyrieImg from '../assets/images/hero-valkyrie.jpg';
import heroTitanImg from '../assets/images/hero-titan.jpg';

export type Language = 'bn' | 'en';

export interface Operator {
  id: 'phantom' | 'valkyrie' | 'titan';
  codename: string;
  realName: string;
  roleEn: string;
  roleBn: string;
  tier: 'MYTHIC' | 'LEGENDARY';
  image: string;
  accentColor: string;
  glowRgba: string;
  skillNameEn: string;
  skillNameBn: string;
  skillDescEn: string;
  skillDescBn: string;
  passiveEn: string;
  passiveBn: string;
  cooldownSec: number;
  stats: {
    mobility: number;
    firepower: number;
    defense: number;
    tech: number;
  };
}

export interface WeaponSpec {
  id: 'solar_ar' | 'vortex_smg' | 'valkyrie_sr' | 'hellfire_sg';
  name: string;
  skinTitleEn: string;
  skinTitleBn: string;
  category: 'ar' | 'smg' | 'sniper' | 'shotgun';
  categoryLabelEn: string;
  categoryLabelBn: string;
  rarity: 'EVO MYTHIC' | 'LEGENDARY';
  accent: string;
  damage: number;
  fireRateMs: number;
  magSize: number;
  reloadMs: number;
  bulletSpeed: number;
  rangePx: number;
  pellets: number;
  spreadRad: number;
  critChance: number;
  unlockCost: number;
  statsUi: {
    damage: number;
    rate: number;
    range: number;
    precision: number;
  };
}

export interface GameModeSpec {
  id: 'br_eclipse' | 'clash_docks' | 'sniper_core';
  nameEn: string;
  nameBn: string;
  subEn: string;
  subBn: string;
  playersCount: number;
  mapSize: number;
  stormSpeed: number;
  badge: string;
  accent: string;
}

export const OPERATORS: Operator[] = [
  {
    id: 'phantom',
    codename: 'KAIRO // PHANTOM',
    realName: 'Kairo Vance',
    roleEn: 'Chrono Striker',
    roleBn: 'ক্রোনো অ্যাসল্ট স্ট্রাইকার',
    tier: 'MYTHIC',
    image: heroPhantomImg,
    accentColor: '#FF9E0B',
    glowRgba: 'rgba(255, 158, 11, 0.35)',
    skillNameEn: 'Solar Overdrive',
    skillNameBn: 'সোলার ওভারড্রাইভ',
    skillDescEn: '+45% Sprint Speed & +35% Fire Rate surge for 4.5s with molten afterimage.',
    skillDescBn: '৪.৫ সেকেন্ডের জন্য ৪৫% দ্রুত গতি এবং ৩৫% ফায়ার রেট বৃদ্ধি পায়।',
    passiveEn: 'Agile Reload (+20% faster magazine swap)',
    passiveBn: 'দ্রুত রিলোড (+২০% ফাস্ট ম্যাগাজিন সোয়াপ)',
    cooldownSec: 12,
    stats: {
      mobility: 96,
      firepower: 92,
      defense: 78,
      tech: 88,
    },
  },
  {
    id: 'valkyrie',
    codename: 'NYX // VALKYRIE',
    realName: 'Nyx Solis',
    roleEn: 'Aether Recon',
    roleBn: 'এথার রিকন স্নাইপার',
    tier: 'MYTHIC',
    image: heroValkyrieImg,
    accentColor: '#00E5FF',
    glowRgba: 'rgba(0, 229, 255, 0.35)',
    skillNameEn: 'Holo-Pulse Scan',
    skillNameBn: 'হলো-পালস রাডার স্ক্যান',
    skillDescEn: 'Reveals all nearby hostiles on tactical HUD & grants +40% Critical Headshot chance for 5s.',
    skillDescBn: '৫ সেকেন্ডের জন্য শত্রুদের লোকেশন স্ক্যান করে এবং হেডশট ক্রিটিক্যাল ড্যামেজ ৪০% বাড়ায়।',
    passiveEn: 'Armor Piercer (+15% bullet velocity)',
    passiveBn: 'আর্মার পিয়ার্সার (+১৫% বুলেট ভেলোসিটি)',
    cooldownSec: 14,
    stats: {
      mobility: 90,
      firepower: 97,
      defense: 72,
      tech: 98,
    },
  },
  {
    id: 'titan',
    codename: 'VANGUARD // TITAN',
    realName: 'Darius Kael',
    roleEn: 'Exo Bastion',
    roleBn: 'এক্সো শিল্ড গার্ডিয়ান',
    tier: 'LEGENDARY',
    image: heroTitanImg,
    accentColor: '#FBBF24',
    glowRgba: 'rgba(251, 191, 36, 0.35)',
    skillNameEn: 'Hex Aegis Dome',
    skillNameBn: 'হেক্স এজিস এনার্জি শিল্ড',
    skillDescEn: 'Instantly restores +65 Armor Shield & reduces incoming ballistic damage by 55% for 5s.',
    skillDescBn: 'সাথে সাথে +৬৫ আর্মার শিল্ড রিস্টোর করে এবং ৫ সেকেন্ডের জন্য শত্রুর ড্যামেজ ৫৫% কমায়।',
    passiveEn: 'Heavy Plating (+40 Max Shield Capacity)',
    passiveBn: 'হেভি প্লেটিং (+৪০ অতিরিক্ত ম্যাক্স শিল্ড)',
    cooldownSec: 13,
    stats: {
      mobility: 78,
      firepower: 89,
      defense: 99,
      tech: 85,
    },
  },
];

export const WEAPONS: WeaponSpec[] = [
  {
    id: 'solar_ar',
    name: 'M4X-SOLAR FLARE',
    skinTitleEn: 'EvoLv.7 Molten Core',
    skinTitleBn: 'ইভো লেভেল-৭ মল্টেন কোর',
    category: 'ar',
    categoryLabelEn: 'ASSAULT RIFLE',
    categoryLabelBn: 'অ্যাসল্ট রাইফেল',
    rarity: 'EVO MYTHIC',
    accent: '#FF9E0B',
    damage: 28,
    fireRateMs: 115,
    magSize: 34,
    reloadMs: 1250,
    bulletSpeed: 18,
    rangePx: 680,
    pellets: 1,
    spreadRad: 0.035,
    critChance: 0.24,
    unlockCost: 0,
    statsUi: { damage: 86, rate: 88, range: 84, precision: 90 },
  },
  {
    id: 'vortex_smg',
    name: 'VORTEX-9 AETHER',
    skinTitleEn: 'EvoLv.7 Cyber Frost',
    skinTitleBn: 'ইভো লেভেল-৭ সাইবার ফ্রস্ট',
    category: 'smg',
    categoryLabelEn: 'HYPER SMG',
    categoryLabelBn: 'হাইপার এসএমজি',
    rarity: 'EVO MYTHIC',
    accent: '#00E5FF',
    damage: 19,
    fireRateMs: 72,
    magSize: 42,
    reloadMs: 1050,
    bulletSpeed: 17,
    rangePx: 510,
    pellets: 1,
    spreadRad: 0.065,
    critChance: 0.22,
    unlockCost: 0,
    statsUi: { damage: 74, rate: 99, range: 68, precision: 84 },
  },
  {
    id: 'valkyrie_sr',
    name: 'AWM-X ECLIPSE RAIL',
    skinTitleEn: 'Mythic Astral Piercer',
    skinTitleBn: 'মিথিক অ্যাস্ট্রাল স্নাইপার',
    category: 'sniper',
    categoryLabelEn: 'RAIL SNIPER',
    categoryLabelBn: 'রেইল স্নাইপার',
    rarity: 'EVO MYTHIC',
    accent: '#38BDF8',
    damage: 92,
    fireRateMs: 680,
    magSize: 8,
    reloadMs: 1550,
    bulletSpeed: 27,
    rangePx: 980,
    pellets: 1,
    spreadRad: 0.006,
    critChance: 0.45,
    unlockCost: 400,
    statsUi: { damage: 99, rate: 48, range: 99, precision: 98 },
  },
  {
    id: 'hellfire_sg',
    name: 'M1887-NOVA BREACH',
    skinTitleEn: 'Legendary Dragon Ember',
    skinTitleBn: 'লেজেন্ডারি ড্রাগন শটগান',
    category: 'shotgun',
    categoryLabelEn: 'PLASMA SHOTGUN',
    categoryLabelBn: 'প্লাজমা শটগান',
    rarity: 'LEGENDARY',
    accent: '#F97316',
    damage: 18, // x6 pellets = 108 close burst!
    fireRateMs: 520,
    magSize: 10,
    reloadMs: 1400,
    bulletSpeed: 16,
    rangePx: 370,
    pellets: 6,
    spreadRad: 0.19,
    critChance: 0.28,
    unlockCost: 300,
    statsUi: { damage: 97, rate: 60, range: 52, precision: 72 },
  },
];

export const GAME_MODES: GameModeSpec[] = [
  {
    id: 'br_eclipse',
    nameEn: 'ECLIPSE ROYALE',
    nameBn: 'ইকলিপ্স ব্যাটেল রয়্যাল',
    subEn: '20 Survivors • Shrinking Aether Zone • Mythic Drops',
    subBn: '২০ জন যোদ্ধা • শ্রিংকিং এথার জোন • মিথিক এয়ারড্রপ',
    playersCount: 20,
    mapSize: 2600,
    stormSpeed: 1,
    badge: 'RANKED BR',
    accent: '#FF9E0B',
  },
  {
    id: 'clash_docks',
    nameEn: 'CYBER CLASH RUSH',
    nameBn: 'সাইবার ক্ল্যাশ রাশ',
    subEn: '12 Survivors • Compact Arena • Fast Gloo-Shield Fights',
    subBn: '১২ জন যোদ্ধা • ক্লোজ-রেঞ্জ ফাস্ট অ্যাকশন এরিনা',
    playersCount: 12,
    mapSize: 1750,
    stormSpeed: 1.45,
    badge: 'TURBO 4X',
    accent: '#00E5FF',
  },
  {
    id: 'sniper_core',
    nameEn: 'SOLAR CORE OVERDRIVE',
    nameBn: 'সোলার কোর ওভারড্রাইভ',
    subEn: '16 Survivors • High Loot • Intense Final Circle',
    subBn: '১৬ জন যোদ্ধা • আল্ট্রা লুট • হাই-ভোল্টেজ ফাইনাল জোন',
    playersCount: 16,
    mapSize: 2100,
    stormSpeed: 1.25,
    badge: 'ELITE',
    accent: '#F43F5E',
  },
];

export const UI_TEXT = {
  bn: {
    lobby: 'কমান্ড লবি',
    heroes: 'অপারেটর',
    armory: 'ইভো অস্ত্রাগার',
    mapIntel: 'ম্যাপ ইন্টেল',
    apkStudio: 'APK ও GitHub পাবলিশ',
    startMatch: 'ম্যাচ শুরু করুন',
    deploying: 'ড্রপ ডিপ্লয় হচ্ছে...',
    rankTitle: 'গ্র্যান্ডমাস্টার IV',
    apkQuickBadge: 'গিটহাব রিলিজ রেডি',
    equippedWeapon: 'নির্বাচিত অস্ত্র',
    activeSkill: 'অ্যাক্টিভ স্কিল',
    selectOperator: 'অপারেটর পরিবর্তন',
    controlsHint: 'PC: WASD মুভ • মাউস ফায়ার • [Q] গ্লু-শিল্ড • [E] স্কিল • [H] হিল | Mobile: ডুয়াল জয়স্টিক ও গ্লাস বাটন',
  },
  en: {
    lobby: 'COMMAND DECK',
    heroes: 'OPERATORS',
    armory: 'EVO ARMORY',
    mapIntel: 'MAP INTEL',
    apkStudio: 'APK & GITHUB STUDIO',
    startMatch: 'DEPLOY TO BATTLE',
    deploying: 'ORBITAL DROP...',
    rankTitle: 'GRANDMASTER IV',
    apkQuickBadge: 'GITHUB APK READY',
    equippedWeapon: 'EQUIPPED WEAPON',
    activeSkill: 'ACTIVE ABILITY',
    selectOperator: 'SWITCH OPERATOR',
    controlsHint: 'PC: WASD Move • Mouse Fire • [Q] Aether Wall • [E] Skill • [H] Heal | Mobile: Dual Touch HUD',
  },
};
